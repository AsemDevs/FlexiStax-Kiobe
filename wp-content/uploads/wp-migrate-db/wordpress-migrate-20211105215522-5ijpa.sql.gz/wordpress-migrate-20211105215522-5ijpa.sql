# WordPress MySQL database migration
#
# Generated: Friday 5. November 2021 21:55 UTC
# Hostname: db:3306
# Database: `wordpress`
# URL: //localhost:8000
# Path: /var/www/html
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_um_metadata, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, nav_menu_item, page, post, um_directory, um_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-07-07 13:59:24', '2021-07-07 13:59:24', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1072 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8000', 'yes'),
(2, 'home', 'http://localhost:8000', 'yes'),
(3, 'blogname', 'Kiobe', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'asem.abdou@flexistax.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%category%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:159:{s:46:"um-download/([^/]+)/([^/]+)/([^/]+)/([^/]+)/?$";s:111:"index.php?um_action=download&um_form=$matches[1]&um_field=$matches[2]&um_user=$matches[3]&um_verify=$matches[4]";s:15:"user/([^/]+)/?$";s:41:"index.php?page_id=149&um_user=$matches[1]";s:17:"account/([^/]+)?$";s:40:"index.php?page_id=159&um_tab=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/um-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&um-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/um-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&um-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"um_form/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"um_form/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"um_form/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"um_form/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"um_form/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"um_form/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"um_form/([^/]+)/embed/?$";s:40:"index.php?um_form=$matches[1]&embed=true";s:28:"um_form/([^/]+)/trackback/?$";s:34:"index.php?um_form=$matches[1]&tb=1";s:36:"um_form/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?um_form=$matches[1]&paged=$matches[2]";s:43:"um_form/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?um_form=$matches[1]&cpage=$matches[2]";s:33:"um_form/([^/]+)/um-api(/(.*))?/?$";s:48:"index.php?um_form=$matches[1]&um-api=$matches[3]";s:39:"um_form/[^/]+/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:50:"um_form/[^/]+/attachment/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:32:"um_form/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?um_form=$matches[1]&page=$matches[2]";s:24:"um_form/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"um_form/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"um_form/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"um_form/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"um_form/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"um_form/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"um_directory/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"um_directory/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"um_directory/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"um_directory/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"um_directory/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"um_directory/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"um_directory/([^/]+)/embed/?$";s:45:"index.php?um_directory=$matches[1]&embed=true";s:33:"um_directory/([^/]+)/trackback/?$";s:39:"index.php?um_directory=$matches[1]&tb=1";s:41:"um_directory/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?um_directory=$matches[1]&paged=$matches[2]";s:48:"um_directory/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?um_directory=$matches[1]&cpage=$matches[2]";s:38:"um_directory/([^/]+)/um-api(/(.*))?/?$";s:53:"index.php?um_directory=$matches[1]&um-api=$matches[3]";s:44:"um_directory/[^/]+/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:55:"um_directory/[^/]+/attachment/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:37:"um_directory/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?um_directory=$matches[1]&page=$matches[2]";s:29:"um_directory/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"um_directory/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"um_directory/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"um_directory/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"um_directory/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"um_directory/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=7&cpage=$matches[1]";s:17:"um-api(/(.*))?/?$";s:29:"index.php?&um-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/um-api(/(.*))?/?$";s:29:"index.php?&um-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/um-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&um-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/um-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&um-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/um-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&um-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/um-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&um-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/um-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&um-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/um-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&um-api=$matches[3]";s:31:".?.+?/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:".+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"(.+?)/([^/]+)/embed/?$";s:63:"index.php?category_name=$matches[1]&name=$matches[2]&embed=true";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:31:"(.+?)/([^/]+)/um-api(/(.*))?/?$";s:71:"index.php?category_name=$matches[1]&name=$matches[2]&um-api=$matches[4]";s:35:".+?/[^/]+/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:46:".+?/[^/]+/attachment/([^/]+)/um-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&um-api=$matches[3]";s:30:"(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:".+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:14:"(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:23:"(.+?)/um-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&um-api=$matches[3]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:35:"ultimate-member/ultimate-member.php";i:1;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:53:"/var/www/html/wp-content/themes/Kiobe-Theme/style.css";i:2;s:0:"";}', 'no'),
(40, 'template', 'Kiobe-Theme', 'yes'),
(41, 'stylesheet', 'Kiobe-Theme', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:2:{s:27:"wp-super-cache/wp-cache.php";s:22:"wpsupercache_uninstall";s:35:"litespeed-cache/litespeed-cache.php";s:47:"LiteSpeed\\Activation::uninstall_litespeed_cache";}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '7', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1641218363', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(107, 'cron', 'a:12:{i:1625666367;a:6:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1625666389;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1625666394;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1625666449;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1625752767;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1625947181;a:1:{s:29:"wp_cache_add_site_cache_index";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1626595657;a:3:{s:27:"litespeed_task_imgoptm_pull";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"litespeed_filter";s:4:"args";a:0:{}s:8:"interval";i:60;}}s:19:"litespeed_task_ccss";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"litespeed_filter";s:4:"args";a:0:{}s:8:"interval";i:60;}}s:19:"litespeed_task_lqip";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"litespeed_filter";s:4:"args";a:0:{}s:8:"interval";i:60;}}}i:1627124334;a:1:{s:8:"do_pings";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1632453334;a:4:{s:26:"um_weekly_scheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:25:"um_daily_scheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"um_twicedaily_scheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:26:"um_hourly_scheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1632539719;a:1:{s:28:"um_check_extensions_licenses";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1635186463;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"b9d400dc2fddafadeca8fb17e9ce138b";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:149;}}}}s:7:"version";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(127, 'can_compress_scripts', '0', 'no'),
(140, 'theme_mods_twentytwentyone', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1626594489;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:9:"sidebar-2";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}}}s:18:"nav_menu_locations";a:1:{s:6:"footer";i:4;}}', 'yes'),
(143, 'current_theme', '', 'yes'),
(144, 'theme_mods_Kiobe Theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1625675268;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(155, 'theme_mods_Kiobe-Theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:14:"bootstrap-menu";i:2;s:11:"footer-menu";i:0;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1627466781;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(160, 'theme_mods_twentynineteen', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:6:"footer";i:4;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1626595912;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(165, 'theme_mods_onepagerx', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1625727349;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:19:"primary-widget-area";a:0:{}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}s:18:"th-woo-widget-area";a:0:{}}}}', 'yes'),
(169, 'recovery_mode_email_last_sent', '1626073011', 'yes'),
(170, 'recovery_keys', 'a:3:{s:22:"A90eWi3rPC4RDmkT2xOwtF";a:2:{s:10:"hashed_key";s:34:"$P$BW5UNx7AoOPRum8hQWe2ERPyalOL71.";s:10:"created_at";i:1625727652;}s:22:"0869oJ4PKxfCRYMaBV8mPk";a:2:{s:10:"hashed_key";s:34:"$P$BsMb95wmpteM6lasaRca8BiFzcULw90";s:10:"created_at";i:1625944840;}s:22:"fkRifsP7T4GVsA5ospaedv";a:2:{s:10:"hashed_key";s:34:"$P$B9hfNBH0P1XOI0AysAXNiqI/JsndDj1";s:10:"created_at";i:1626073011;}}', 'yes'),
(171, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes'),
(188, 'recently_activated', 'a:0:{}', 'yes'),
(236, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";s:5:"assem";s:15:"connection_type";s:3:"ftp";}', 'yes'),
(283, 'litespeed.cloud._summary', 'a:5:{s:19:"curr_request.wp/ver";i:0;s:19:"last_request.wp/ver";i:1626595656;s:10:"news.utime";i:1626595657;s:20:"curr_request.wp/news";i:0;s:20:"last_request.wp/news";i:1626595657;}', 'yes'),
(284, 'litespeed.conf._version', '3.6.4', 'yes'),
(285, 'litespeed.conf.hash', 'l8GJXCrXOSeCMA8obCq7aLzaywvGjIP6', 'yes'),
(286, 'litespeed.conf.auto_upgrade', '', 'yes'),
(287, 'litespeed.conf.api_key', '', 'yes'),
(288, 'litespeed.conf.server_ip', '', 'yes'),
(289, 'litespeed.conf.news', '1', 'yes'),
(290, 'litespeed.conf.cache', '1', 'yes'),
(291, 'litespeed.conf.cache-priv', '1', 'yes'),
(292, 'litespeed.conf.cache-commenter', '1', 'yes'),
(293, 'litespeed.conf.cache-rest', '1', 'yes'),
(294, 'litespeed.conf.cache-page_login', '1', 'yes'),
(295, 'litespeed.conf.cache-favicon', '1', 'yes'),
(296, 'litespeed.conf.cache-resources', '1', 'yes'),
(297, 'litespeed.conf.cache-mobile', '', 'yes'),
(298, 'litespeed.conf.cache-mobile_rules', 'a:7:{i:0;s:6:"Mobile";i:1;s:7:"Android";i:2;s:5:"Silk/";i:3;s:6:"Kindle";i:4;s:10:"BlackBerry";i:5;s:10:"Opera Mini";i:6;s:10:"Opera Mobi";}', 'yes'),
(299, 'litespeed.conf.cache-browser', '', 'yes'),
(300, 'litespeed.conf.cache-exc_useragents', 'a:0:{}', 'yes'),
(301, 'litespeed.conf.cache-exc_cookies', 'a:0:{}', 'yes'),
(302, 'litespeed.conf.cache-exc_qs', 'a:0:{}', 'yes'),
(303, 'litespeed.conf.cache-exc_cat', 'a:0:{}', 'yes'),
(304, 'litespeed.conf.cache-exc_tag', 'a:0:{}', 'yes'),
(305, 'litespeed.conf.cache-force_uri', 'a:0:{}', 'yes'),
(306, 'litespeed.conf.cache-force_pub_uri', 'a:0:{}', 'yes'),
(307, 'litespeed.conf.cache-priv_uri', 'a:0:{}', 'yes'),
(308, 'litespeed.conf.cache-exc', 'a:0:{}', 'yes'),
(309, 'litespeed.conf.cache-exc_roles', 'a:0:{}', 'yes'),
(310, 'litespeed.conf.cache-drop_qs', 'a:4:{i:0;s:6:"fbclid";i:1;s:5:"gclid";i:2;s:4:"utm*";i:3;s:3:"_ga";}', 'yes'),
(311, 'litespeed.conf.cache-ttl_pub', '604800', 'yes'),
(312, 'litespeed.conf.cache-ttl_priv', '1800', 'yes'),
(313, 'litespeed.conf.cache-ttl_frontpage', '604800', 'yes'),
(314, 'litespeed.conf.cache-ttl_feed', '604800', 'yes'),
(315, 'litespeed.conf.cache-ttl_rest', '604800', 'yes'),
(316, 'litespeed.conf.cache-ttl_browser', '31557600', 'yes'),
(317, 'litespeed.conf.cache-ttl_status', 'a:3:{i:0;s:8:"403 3600";i:1;s:8:"404 3600";i:2;s:8:"500 3600";}', 'yes'),
(318, 'litespeed.conf.cache-login_cookie', '', 'yes'),
(319, 'litespeed.conf.cache-vary_group', 'a:0:{}', 'yes'),
(320, 'litespeed.conf.purge-upgrade', '1', 'yes'),
(321, 'litespeed.conf.purge-stale', '', 'yes'),
(322, 'litespeed.conf.purge-post_all', '', 'yes'),
(323, 'litespeed.conf.purge-post_f', '1', 'yes'),
(324, 'litespeed.conf.purge-post_h', '1', 'yes'),
(325, 'litespeed.conf.purge-post_p', '1', 'yes'),
(326, 'litespeed.conf.purge-post_pwrp', '1', 'yes'),
(327, 'litespeed.conf.purge-post_a', '1', 'yes'),
(328, 'litespeed.conf.purge-post_y', '', 'yes'),
(329, 'litespeed.conf.purge-post_m', '1', 'yes'),
(330, 'litespeed.conf.purge-post_d', '', 'yes'),
(331, 'litespeed.conf.purge-post_t', '1', 'yes'),
(332, 'litespeed.conf.purge-post_pt', '1', 'yes'),
(333, 'litespeed.conf.purge-timed_urls', 'a:0:{}', 'yes'),
(334, 'litespeed.conf.purge-timed_urls_time', '', 'yes'),
(335, 'litespeed.conf.purge-hook_all', 'a:10:{i:0;s:12:"switch_theme";i:1;s:18:"wp_create_nav_menu";i:2;s:18:"wp_update_nav_menu";i:3;s:18:"wp_delete_nav_menu";i:4;s:11:"create_term";i:5;s:10:"edit_terms";i:6;s:11:"delete_term";i:7;s:8:"add_link";i:8;s:9:"edit_link";i:9;s:11:"delete_link";}', 'yes'),
(336, 'litespeed.conf.esi', '', 'yes'),
(337, 'litespeed.conf.esi-cache_admbar', '1', 'yes'),
(338, 'litespeed.conf.esi-cache_commform', '1', 'yes'),
(339, 'litespeed.conf.esi-nonce', 'a:2:{i:0;s:11:"stats_nonce";i:1;s:15:"subscribe_nonce";}', 'yes'),
(340, 'litespeed.conf.util-instant_click', '', 'yes'),
(341, 'litespeed.conf.util-no_https_vary', '', 'yes'),
(342, 'litespeed.conf.debug-disable_all', '', 'yes'),
(343, 'litespeed.conf.debug', '', 'yes'),
(344, 'litespeed.conf.debug-ips', 'a:1:{i:0;s:9:"127.0.0.1";}', 'yes'),
(345, 'litespeed.conf.debug-level', '', 'yes'),
(346, 'litespeed.conf.debug-filesize', '3', 'yes'),
(347, 'litespeed.conf.debug-cookie', '', 'yes'),
(348, 'litespeed.conf.debug-collaps_qs', '', 'yes'),
(349, 'litespeed.conf.debug-inc', 'a:0:{}', 'yes'),
(350, 'litespeed.conf.debug-exc', 'a:0:{}', 'yes'),
(351, 'litespeed.conf.db_optm-revisions_max', '0', 'yes'),
(352, 'litespeed.conf.db_optm-revisions_age', '0', 'yes'),
(353, 'litespeed.conf.optm-css_min', '', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(354, 'litespeed.conf.optm-css_comb', '', 'yes'),
(355, 'litespeed.conf.optm-css_comb_ext_inl', '', 'yes'),
(356, 'litespeed.conf.optm-ucss', '', 'yes'),
(357, 'litespeed.conf.optm-ucss_async', '', 'yes'),
(358, 'litespeed.conf.optm-css_http2', '', 'yes'),
(359, 'litespeed.conf.optm-css_exc', 'a:0:{}', 'yes'),
(360, 'litespeed.conf.optm-js_min', '', 'yes'),
(361, 'litespeed.conf.optm-js_comb', '', 'yes'),
(362, 'litespeed.conf.optm-js_comb_ext_inl', '', 'yes'),
(363, 'litespeed.conf.optm-js_http2', '', 'yes'),
(364, 'litespeed.conf.optm-js_exc', 'a:2:{i:0;s:9:"jquery.js";i:1;s:13:"jquery.min.js";}', 'yes'),
(365, 'litespeed.conf.optm-ttl', '604800', 'yes'),
(366, 'litespeed.conf.optm-html_min', '', 'yes'),
(367, 'litespeed.conf.optm-qs_rm', '', 'yes'),
(368, 'litespeed.conf.optm-ggfonts_rm', '', 'yes'),
(369, 'litespeed.conf.optm-css_async', '', 'yes'),
(370, 'litespeed.conf.optm-ccss_gen', '1', 'yes'),
(371, 'litespeed.conf.optm-ccss_async', '1', 'yes'),
(372, 'litespeed.conf.optm-css_async_inline', '1', 'yes'),
(373, 'litespeed.conf.optm-css_font_display', '', 'yes'),
(374, 'litespeed.conf.optm-js_defer', '', 'yes'),
(375, 'litespeed.conf.optm-js_inline_defer', '', 'yes'),
(376, 'litespeed.conf.optm-emoji_rm', '', 'yes'),
(377, 'litespeed.conf.optm-noscript_rm', '', 'yes'),
(378, 'litespeed.conf.optm-ggfonts_async', '', 'yes'),
(379, 'litespeed.conf.optm-exc_roles', 'a:0:{}', 'yes'),
(380, 'litespeed.conf.optm-ccss_con', '', 'yes'),
(381, 'litespeed.conf.optm-js_defer_exc', 'a:2:{i:0;s:9:"jquery.js";i:1;s:13:"jquery.min.js";}', 'yes'),
(382, 'litespeed.conf.optm-dns_prefetch', 'a:0:{}', 'yes'),
(383, 'litespeed.conf.optm-dns_prefetch_ctrl', '', 'yes'),
(384, 'litespeed.conf.optm-exc', 'a:0:{}', 'yes'),
(385, 'litespeed.conf.optm-ccss_sep_posttype', 'a:0:{}', 'yes'),
(386, 'litespeed.conf.optm-ccss_sep_uri', 'a:0:{}', 'yes'),
(387, 'litespeed.conf.object', '', 'yes'),
(388, 'litespeed.conf.object-kind', '', 'yes'),
(389, 'litespeed.conf.object-host', 'localhost', 'yes'),
(390, 'litespeed.conf.object-port', '11211', 'yes'),
(391, 'litespeed.conf.object-life', '360', 'yes'),
(392, 'litespeed.conf.object-persistent', '1', 'yes'),
(393, 'litespeed.conf.object-admin', '1', 'yes'),
(394, 'litespeed.conf.object-transients', '1', 'yes'),
(395, 'litespeed.conf.object-db_id', '0', 'yes'),
(396, 'litespeed.conf.object-user', '', 'yes'),
(397, 'litespeed.conf.object-pswd', '', 'yes'),
(398, 'litespeed.conf.object-global_groups', 'a:12:{i:0;s:5:"users";i:1;s:10:"userlogins";i:2;s:8:"usermeta";i:3;s:9:"user_meta";i:4;s:14:"site-transient";i:5;s:12:"site-options";i:6;s:11:"site-lookup";i:7;s:11:"blog-lookup";i:8;s:12:"blog-details";i:9;s:3:"rss";i:10;s:12:"global-posts";i:11;s:13:"blog-id-cache";}', 'yes'),
(399, 'litespeed.conf.object-non_persistent_groups', 'a:4:{i:0;s:7:"comment";i:1;s:6:"counts";i:2;s:7:"plugins";i:3;s:13:"wc_session_id";}', 'yes'),
(400, 'litespeed.conf.discuss-avatar_cache', '', 'yes'),
(401, 'litespeed.conf.discuss-avatar_cron', '', 'yes'),
(402, 'litespeed.conf.discuss-avatar_cache_ttl', '604800', 'yes'),
(403, 'litespeed.conf.optm-localize', '', 'yes'),
(404, 'litespeed.conf.optm-localize_domains', 'a:7:{i:0;s:23:"### Popular scripts ###";i:1;s:39:"https://platform.twitter.com/widgets.js";i:2;s:39:"https://www.google.com/recaptcha/api.js";i:3;s:45:"https://www.google-analytics.com/analytics.js";i:4;s:39:"https://www.googletagmanager.com/gtm.js";i:5;s:47:"https://www.googletagservices.com/tag/js/gpt.js";i:6;s:46:"https://connect.facebook.net/en_US/fbevents.js";}', 'yes'),
(405, 'litespeed.conf.media-lazy', '', 'yes'),
(406, 'litespeed.conf.media-lazy_placeholder', '', 'yes'),
(407, 'litespeed.conf.media-placeholder_resp', '', 'yes'),
(408, 'litespeed.conf.media-placeholder_resp_color', '#cfd4db', 'yes'),
(409, 'litespeed.conf.media-placeholder_resp_svg', '<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="{color}"/></svg>', 'yes'),
(410, 'litespeed.conf.media-lqip', '', 'yes'),
(411, 'litespeed.conf.media-lqip_qual', '4', 'yes'),
(412, 'litespeed.conf.media-lqip_min_w', '150', 'yes'),
(413, 'litespeed.conf.media-lqip_min_h', '150', 'yes'),
(414, 'litespeed.conf.media-placeholder_resp_async', '1', 'yes'),
(415, 'litespeed.conf.media-iframe_lazy', '', 'yes'),
(416, 'litespeed.conf.media-lazyjs_inline', '', 'yes'),
(417, 'litespeed.conf.media-lazy_exc', 'a:0:{}', 'yes'),
(418, 'litespeed.conf.media-lazy_cls_exc', 'a:1:{i:0;s:15:"wmu-preview-img";}', 'yes'),
(419, 'litespeed.conf.media-lazy_parent_cls_exc', 'a:0:{}', 'yes'),
(420, 'litespeed.conf.media-iframe_lazy_cls_exc', 'a:0:{}', 'yes'),
(421, 'litespeed.conf.media-iframe_lazy_parent_cls_exc', 'a:0:{}', 'yes'),
(422, 'litespeed.conf.media-lazy_uri_exc', 'a:0:{}', 'yes'),
(423, 'litespeed.conf.media-lqip_exc', 'a:0:{}', 'yes'),
(424, 'litespeed.conf.img_optm-auto', '', 'yes'),
(425, 'litespeed.conf.img_optm-cron', '1', 'yes'),
(426, 'litespeed.conf.img_optm-ori', '1', 'yes'),
(427, 'litespeed.conf.img_optm-rm_bkup', '', 'yes'),
(428, 'litespeed.conf.img_optm-webp', '', 'yes'),
(429, 'litespeed.conf.img_optm-lossless', '', 'yes'),
(430, 'litespeed.conf.img_optm-exif', '', 'yes'),
(431, 'litespeed.conf.img_optm-webp_replace', '', 'yes'),
(432, 'litespeed.conf.img_optm-webp_attr', 'a:7:{i:0;s:7:"img.src";i:1;s:14:"div.data-thumb";i:2;s:12:"img.data-src";i:3;s:20:"div.data-large_image";i:4;s:19:"img.retina_logo_url";i:5;s:23:"div.data-parallax-image";i:6;s:12:"video.poster";}', 'yes'),
(433, 'litespeed.conf.img_optm-webp_replace_srcset', '', 'yes'),
(434, 'litespeed.conf.img_optm-jpg_quality', '82', 'yes'),
(435, 'litespeed.conf.crawler', '', 'yes'),
(436, 'litespeed.conf.crawler-usleep', '500', 'yes'),
(437, 'litespeed.conf.crawler-run_duration', '400', 'yes'),
(438, 'litespeed.conf.crawler-run_interval', '600', 'yes'),
(439, 'litespeed.conf.crawler-crawl_interval', '302400', 'yes'),
(440, 'litespeed.conf.crawler-threads', '3', 'yes'),
(441, 'litespeed.conf.crawler-timeout', '30', 'yes'),
(442, 'litespeed.conf.crawler-load_limit', '1', 'yes'),
(443, 'litespeed.conf.crawler-sitemap', '', 'yes'),
(444, 'litespeed.conf.crawler-drop_domain', '1', 'yes'),
(445, 'litespeed.conf.crawler-map_timeout', '120', 'yes'),
(446, 'litespeed.conf.crawler-roles', 'a:0:{}', 'yes'),
(447, 'litespeed.conf.crawler-cookies', 'a:0:{}', 'yes'),
(448, 'litespeed.conf.misc-htaccess_front', '', 'yes'),
(449, 'litespeed.conf.misc-htaccess_back', '', 'yes'),
(450, 'litespeed.conf.misc-heartbeat_front', '', 'yes'),
(451, 'litespeed.conf.misc-heartbeat_front_ttl', '60', 'yes'),
(452, 'litespeed.conf.misc-heartbeat_back', '', 'yes'),
(453, 'litespeed.conf.misc-heartbeat_back_ttl', '60', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(454, 'litespeed.conf.misc-heartbeat_editor', '', 'yes'),
(455, 'litespeed.conf.misc-heartbeat_editor_ttl', '15', 'yes'),
(456, 'litespeed.conf.cdn', '', 'yes'),
(457, 'litespeed.conf.cdn-ori', 'a:0:{}', 'yes'),
(458, 'litespeed.conf.cdn-ori_dir', 'a:2:{i:0;s:10:"wp-content";i:1;s:11:"wp-includes";}', 'yes'),
(459, 'litespeed.conf.cdn-exc', 'a:0:{}', 'yes'),
(460, 'litespeed.conf.cdn-quic', '', 'yes'),
(461, 'litespeed.conf.cdn-cloudflare', '', 'yes'),
(462, 'litespeed.conf.cdn-cloudflare_email', '', 'yes'),
(463, 'litespeed.conf.cdn-cloudflare_key', '', 'yes'),
(464, 'litespeed.conf.cdn-cloudflare_name', '', 'yes'),
(465, 'litespeed.conf.cdn-cloudflare_zone', '', 'yes'),
(466, 'litespeed.conf.cdn-mapping', 'a:1:{i:0;a:5:{s:3:"url";b:0;s:7:"inc_img";s:1:"1";s:7:"inc_css";s:1:"1";s:6:"inc_js";s:1:"1";s:8:"filetype";a:17:{i:0;s:4:".aac";i:1;s:4:".css";i:2;s:4:".eot";i:3;s:4:".gif";i:4;s:5:".jpeg";i:5;s:3:".js";i:6;s:4:".jpg";i:7;s:5:".less";i:8;s:4:".mp3";i:9;s:4:".mp4";i:10;s:4:".ogg";i:11;s:4:".otf";i:12;s:4:".pdf";i:13;s:4:".png";i:14;s:4:".svg";i:15;s:4:".ttf";i:16;s:5:".woff";}}}', 'yes'),
(467, 'litespeed.conf.cdn-attr', 'a:5:{i:0;s:4:".src";i:1;s:9:".data-src";i:2;s:5:".href";i:3;s:7:".poster";i:4;s:13:"source.srcset";}', 'yes'),
(469, 'litespeed.gui._summary', 'a:2:{s:11:"new_version";i:1626682057;s:5:"score";i:1627027657;}', 'yes'),
(470, 'litespeed.optimize.timestamp_purge_css', '1626595664', 'yes'),
(498, 'theme_mods_understrap-main', 'a:7:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:28:"understrap_posts_index_style";s:7:"default";s:27:"understrap_sidebar_position";s:5:"right";s:25:"understrap_container_type";s:9:"container";s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1627467290;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"right-sidebar";a:0:{}s:12:"left-sidebar";a:0:{}s:4:"hero";a:0:{}s:10:"herocanvas";a:0:{}s:10:"statichero";a:0:{}s:10:"footerfull";a:0:{}}}}', 'yes'),
(870, 'um_last_version_upgrade', '2.2.5', 'yes'),
(871, 'um_first_activation_date', '1632453319', 'yes'),
(872, 'um_version', '2.2.5', 'yes'),
(873, '__ultimatemember_sitekey', 'localhost:8000-ksZxaOb6DaGSr1zrqUiC', 'yes'),
(874, 'um_is_installed', '1', 'yes'),
(875, 'um_core_forms', 'a:3:{s:8:"register";i:138;s:5:"login";i:139;s:7:"profile";i:140;}', 'yes'),
(876, 'um_core_directories', 'a:1:{s:7:"members";i:141;}', 'yes'),
(877, 'um_options', 'a:173:{s:30:"restricted_access_post_metabox";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:31:"disable_restriction_pre_queries";i:0;s:19:"uninstall_on_delete";i:0;s:14:"permalink_base";s:10:"user_login";s:12:"display_name";s:9:"full_name";s:18:"display_name_field";s:0:"";s:15:"author_redirect";i:1;s:12:"members_page";i:1;s:13:"use_gravatars";i:0;s:37:"use_um_gravatar_default_builtin_image";s:7:"default";s:29:"use_um_gravatar_default_image";i:0;s:24:"reset_require_strongpass";i:0;s:18:"password_min_chars";i:8;s:18:"password_max_chars";i:30;s:20:"account_tab_password";i:1;s:19:"account_tab_privacy";i:1;s:25:"account_tab_notifications";i:1;s:18:"account_tab_delete";i:1;s:19:"delete_account_text";s:151:"Are you sure you want to delete your account? This will erase all of your account data from the site. To delete your account enter your password below.";s:36:"delete_account_no_pass_required_text";s:152:"Are you sure you want to delete your account? This will erase all of your account data from the site. To delete your account, click on the button below.";s:12:"account_name";i:1;s:20:"account_name_disable";i:0;s:20:"account_name_require";i:1;s:13:"account_email";i:1;s:24:"account_general_password";i:0;s:25:"account_hide_in_directory";i:1;s:33:"account_hide_in_directory_default";s:2:"No";s:26:"account_require_strongpass";i:0;s:17:"photo_thumb_sizes";a:3:{i:0;i:40;i:1;i:80;i:2;i:190;}s:17:"cover_thumb_sizes";a:2:{i:0;i:300;i:1;i:600;}s:10:"accessible";i:0;s:15:"access_redirect";s:0:"";s:19:"access_exclude_uris";a:0:{}s:20:"home_page_accessible";i:1;s:24:"category_page_accessible";i:1;s:29:"restricted_post_title_replace";i:1;s:28:"restricted_access_post_title";s:18:"Restricted content";s:25:"restricted_access_message";s:0:"";s:17:"restricted_blocks";i:0;s:13:"enable_blocks";i:0;s:24:"restricted_block_message";s:0:"";s:27:"enable_reset_password_limit";i:1;s:27:"reset_password_limit_number";i:3;s:14:"blocked_emails";s:0:"";s:13:"blocked_words";s:47:"admin\r\nadministrator\r\nwebmaster\r\nsupport\r\nstaff";s:14:"default_avatar";s:0:"";s:13:"default_cover";s:0:"";s:28:"disable_profile_photo_upload";i:0;s:21:"profile_show_metaicon";i:0;s:12:"profile_menu";i:1;s:24:"profile_menu_default_tab";s:4:"main";s:18:"profile_menu_icons";i:1;s:13:"form_asterisk";i:0;s:13:"profile_title";s:28:"{display_name} | {site_name}";s:12:"profile_desc";s:83:"{display_name} is on {site_name}. Join {site_name} to view {display_name}\'s profile";s:11:"admin_email";s:24:"asem.abdou@flexistax.com";s:9:"mail_from";s:5:"Kiobe";s:14:"mail_from_addr";s:24:"asem.abdou@flexistax.com";s:10:"email_html";i:1;s:25:"image_orientation_by_exif";i:0;s:17:"image_compression";i:60;s:15:"image_max_width";i:1000;s:15:"cover_min_width";i:1000;s:22:"profile_photo_max_size";i:999999999;s:20:"cover_photo_max_size";i:999999999;s:22:"custom_roles_increment";i:1;s:28:"um_profile_object_cache_stop";i:0;s:16:"rest_api_version";s:3:"2.0";s:26:"member_directory_own_table";i:0;s:21:"profile_show_html_bio";i:0;s:15:"profile_noindex";i:0;s:27:"activation_link_expiry_time";s:0:"";s:16:"profile_tab_main";i:1;s:24:"profile_tab_main_privacy";i:0;s:22:"profile_tab_main_roles";s:0:"";s:17:"profile_tab_posts";i:1;s:25:"profile_tab_posts_privacy";i:0;s:23:"profile_tab_posts_roles";s:0:"";s:20:"profile_tab_comments";i:1;s:28:"profile_tab_comments_privacy";i:0;s:26:"profile_tab_comments_roles";s:0:"";s:16:"welcome_email_on";b:1;s:17:"welcome_email_sub";s:23:"Welcome to {site_name}!";s:13:"welcome_email";s:365:"Hi {display_name},<br /><br />Thank you for signing up with {site_name}! Your account is now active.<br /><br />To login please visit the following url:<br /><br />{login_url} <br /><br />Your account e-mail: {email} <br />Your account username: {username} <br /><br />If you have any problems, please contact us at {admin_email}<br /><br />Thanks,<br />{site_name}";s:18:"checkmail_email_on";b:0;s:19:"checkmail_email_sub";s:28:"Please activate your account";s:15:"checkmail_email";s:304:"Hi {display_name},<br /><br />Thank you for signing up with {site_name}! To activate your account, please click the link below to confirm your email address:<br /><br />{account_activation_link} <br /><br />If you have any problems, please contact us at {admin_email}<br /><br />Thanks, <br />{site_name}";s:16:"pending_email_on";b:0;s:17:"pending_email_sub";s:30:"[{site_name}] New user account";s:13:"pending_email";s:309:"Hi {display_name}, <br /><br />Thank you for signing up with {site_name}! Your account is currently being reviewed by a member of our team.<br /><br />Please allow us some time to process your request.<br /><br />If you have any problems, please contact us at {admin_email}<br /><br />Thanks,<br />{site_name}";s:17:"approved_email_on";b:0;s:18:"approved_email_sub";s:41:"Your account at {site_name} is now active";s:14:"approved_email";s:438:"Hi {display_name},<br /><br />Thank you for signing up with {site_name}! Your account has been approved and is now active.<br /><br />To login please visit the following url:<br /><br />{login_url}<br /><br />Your account e-mail: {email}<br />Your account username: {username}<br />Set your account password: {password_reset_link}<br /><br />If you have any problems, please contact us at {admin_email}<br /><br />Thanks,<br />{site_name}";s:17:"rejected_email_on";b:0;s:18:"rejected_email_sub";s:30:"Your account has been rejected";s:14:"rejected_email";s:288:"Hi {display_name},<br /><br />Thank you for applying for membership to {site_name}! We have reviewed your information and unfortunately we are unable to accept you as a member at this moment.<br /><br />Please feel free to apply again at a future date.<br /><br />Thanks,<br />{site_name}";s:17:"inactive_email_on";b:1;s:18:"inactive_email_sub";s:33:"Your account has been deactivated";s:14:"inactive_email";s:250:"Hi {display_name},<br /><br />This is an automated email to let you know your {site_name} account has been deactivated.<br /><br />If you would like your account to be reactivated please contact us at {admin_email}<br /><br />Thanks,<br />{site_name}";s:17:"deletion_email_on";b:1;s:18:"deletion_email_sub";s:29:"Your account has been deleted";s:14:"deletion_email";s:355:"Hi {display_name},<br /><br />This is an automated email to let you know your {site_name} account has been deleted. All of your personal information has been permanently deleted and you will no longer be able to login to {site_name}.<br /><br />If your account has been deleted by accident please contact us at {admin_email} <br />Thanks,<br />{site_name}";s:16:"resetpw_email_on";b:1;s:17:"resetpw_email_sub";s:19:"Reset your password";s:13:"resetpw_email";s:303:"Hi {display_name},<br /><br />We received a request to reset the password for your account. If you made this request, click the link below to change your password:<br /><br />{password_reset_link}<br /><br />If you didn\'t make this request, you can ignore this email <br /><br />Thanks,<br />{site_name}";s:18:"changedpw_email_on";b:1;s:19:"changedpw_email_sub";s:42:"Your {site_name} password has been changed";s:15:"changedpw_email";s:307:"Hi {display_name},<br /><br />You recently changed the password associated with your {site_name} account.<br /><br />If you did not make this change and believe your {site_name} account has been compromised, please contact us at the following email address: {admin_email}<br /><br />Thanks,<br />{site_name}";s:23:"changedaccount_email_on";b:1;s:24:"changedaccount_email_sub";s:39:"Your account at {site_name} was updated";s:20:"changedaccount_email";s:278:"Hi {display_name},<br /><br />You recently updated your {site_name} account.<br /><br />If you did not make this change and believe your {site_name} account has been compromised, please contact us at the following email address: {admin_email}<br /><br />Thanks,<br />{site_name}";s:24:"notification_new_user_on";b:1;s:25:"notification_new_user_sub";s:30:"[{site_name}] New user account";s:21:"notification_new_user";s:211:"{display_name} has just created an account on {site_name}. To view their profile click here:<br /><br />{user_profile_link}<br /><br />Here is the submitted registration form:<br /><br />{submitted_registration}";s:22:"notification_review_on";b:0;s:23:"notification_review_sub";s:38:"[{site_name}] New user awaiting review";s:19:"notification_review";s:277:"{display_name} has just applied for membership to {site_name} and is waiting to be reviewed.<br /><br />To review this member please click the following link:<br /><br />{user_profile_link}<br /><br />Here is the submitted registration form:<br /><br />{submitted_registration}";s:24:"notification_deletion_on";b:0;s:25:"notification_deletion_sub";s:29:"[{site_name}] Account deleted";s:21:"notification_deletion";s:58:"{display_name} has just deleted their {site_name} account.";s:9:"core_user";i:149;s:10:"core_login";i:151;s:13:"core_register";i:153;s:12:"core_members";i:155;s:11:"core_logout";i:157;s:12:"core_account";i:159;s:19:"core_password-reset";i:161;s:17:"profile_show_name";i:1;s:25:"profile_show_social_links";i:0;s:16:"profile_show_bio";i:1;s:20:"profile_bio_maxchars";i:180;s:19:"profile_header_menu";s:2:"bc";s:18:"profile_empty_text";i:1;s:22:"profile_empty_text_emo";i:1;s:12:"profile_role";a:0:{}s:16:"profile_template";s:7:"profile";s:17:"profile_max_width";s:6:"1000px";s:22:"profile_area_max_width";s:5:"600px";s:13:"profile_align";s:6:"center";s:13:"profile_icons";s:5:"label";s:28:"profile_disable_photo_upload";i:0;s:17:"profile_photosize";s:3:"190";s:21:"profile_cover_enabled";i:1;s:17:"profile_coversize";s:8:"original";s:19:"profile_cover_ratio";s:5:"2.7:1";s:19:"profile_photocorner";s:1:"1";s:17:"profile_header_bg";s:0:"";s:24:"profile_primary_btn_word";s:14:"Update Profile";s:21:"profile_secondary_btn";s:1:"1";s:26:"profile_secondary_btn_word";s:6:"Cancel";s:13:"register_role";s:1:"0";s:17:"register_template";s:8:"register";s:18:"register_max_width";s:5:"450px";s:14:"register_align";s:6:"center";s:14:"register_icons";s:5:"label";s:25:"register_primary_btn_word";s:8:"Register";s:22:"register_secondary_btn";i:1;s:27:"register_secondary_btn_word";s:5:"Login";s:26:"register_secondary_btn_url";s:0:"";s:14:"login_template";s:5:"login";s:15:"login_max_width";s:5:"450px";s:11:"login_align";s:6:"center";s:11:"login_icons";s:5:"label";s:22:"login_primary_btn_word";s:5:"Login";s:22:"login_forgot_pass_link";i:1;s:21:"login_show_rememberme";i:1;s:19:"login_secondary_btn";i:1;s:24:"login_secondary_btn_word";s:8:"Register";s:23:"login_secondary_btn_url";s:0:"";s:18:"directory_template";s:7:"members";s:16:"directory_header";s:21:"{total_users} Members";s:23:"directory_header_single";s:20:"{total_users} Member";s:14:"pages_settings";s:1:"1";}', 'yes'),
(878, 'um_role_subscriber_meta', 'a:14:{s:22:"_um_can_access_wpadmin";i:0;s:24:"_um_can_not_see_adminbar";i:1;s:21:"_um_can_edit_everyone";i:0;s:23:"_um_can_delete_everyone";i:0;s:20:"_um_can_edit_profile";i:1;s:22:"_um_can_delete_profile";i:1;s:15:"_um_after_login";s:16:"redirect_profile";s:16:"_um_after_logout";s:13:"redirect_home";s:20:"_um_default_homepage";i:1;s:16:"_um_can_view_all";i:1;s:28:"_um_can_make_private_profile";i:0;s:30:"_um_can_access_private_profile";i:0;s:10:"_um_status";s:8:"approved";s:20:"_um_auto_approve_act";s:16:"redirect_profile";}', 'yes'),
(879, 'um_role_author_meta', 'a:14:{s:22:"_um_can_access_wpadmin";i:0;s:24:"_um_can_not_see_adminbar";i:1;s:21:"_um_can_edit_everyone";i:0;s:23:"_um_can_delete_everyone";i:0;s:20:"_um_can_edit_profile";i:1;s:22:"_um_can_delete_profile";i:1;s:15:"_um_after_login";s:16:"redirect_profile";s:16:"_um_after_logout";s:13:"redirect_home";s:20:"_um_default_homepage";i:1;s:16:"_um_can_view_all";i:1;s:28:"_um_can_make_private_profile";i:0;s:30:"_um_can_access_private_profile";i:0;s:10:"_um_status";s:8:"approved";s:20:"_um_auto_approve_act";s:16:"redirect_profile";}', 'yes'),
(880, 'um_role_contributor_meta', 'a:14:{s:22:"_um_can_access_wpadmin";i:0;s:24:"_um_can_not_see_adminbar";i:1;s:21:"_um_can_edit_everyone";i:0;s:23:"_um_can_delete_everyone";i:0;s:20:"_um_can_edit_profile";i:1;s:22:"_um_can_delete_profile";i:1;s:15:"_um_after_login";s:16:"redirect_profile";s:16:"_um_after_logout";s:13:"redirect_home";s:20:"_um_default_homepage";i:1;s:16:"_um_can_view_all";i:1;s:28:"_um_can_make_private_profile";i:0;s:30:"_um_can_access_private_profile";i:0;s:10:"_um_status";s:8:"approved";s:20:"_um_auto_approve_act";s:16:"redirect_profile";}', 'yes'),
(881, 'um_role_editor_meta', 'a:14:{s:22:"_um_can_access_wpadmin";i:0;s:24:"_um_can_not_see_adminbar";i:1;s:21:"_um_can_edit_everyone";i:0;s:23:"_um_can_delete_everyone";i:0;s:20:"_um_can_edit_profile";i:1;s:22:"_um_can_delete_profile";i:1;s:15:"_um_after_login";s:16:"redirect_profile";s:16:"_um_after_logout";s:13:"redirect_home";s:20:"_um_default_homepage";i:1;s:16:"_um_can_view_all";i:1;s:28:"_um_can_make_private_profile";i:0;s:30:"_um_can_access_private_profile";i:0;s:10:"_um_status";s:8:"approved";s:20:"_um_auto_approve_act";s:16:"redirect_profile";}', 'yes'),
(882, 'um_role_administrator_meta', 'a:14:{s:22:"_um_can_access_wpadmin";i:1;s:24:"_um_can_not_see_adminbar";i:0;s:21:"_um_can_edit_everyone";i:1;s:23:"_um_can_delete_everyone";i:1;s:20:"_um_can_edit_profile";i:1;s:22:"_um_can_delete_profile";i:1;s:20:"_um_default_homepage";i:1;s:15:"_um_after_login";s:14:"redirect_admin";s:16:"_um_after_logout";s:13:"redirect_home";s:16:"_um_can_view_all";i:1;s:28:"_um_can_make_private_profile";i:1;s:30:"_um_can_access_private_profile";i:1;s:10:"_um_status";s:8:"approved";s:20:"_um_auto_approve_act";s:16:"redirect_profile";}', 'yes'),
(883, 'widget_um_search_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(884, 'um_cache_userdata_1', 'a:97:{s:2:"ID";i:1;s:10:"user_login";s:4:"root";s:9:"user_pass";s:34:"$P$BjxVGMnz.SOY2/a0/bPRAGhS7x0ptc1";s:13:"user_nicename";s:4:"root";s:10:"user_email";s:24:"asem.abdou@flexistax.com";s:8:"user_url";s:21:"http://localhost:8000";s:15:"user_registered";s:19:"2021-07-07 13:59:24";s:11:"user_status";s:1:"0";s:12:"display_name";s:4:"root";s:13:"administrator";b:1;s:8:"wp_roles";s:13:"administrator";s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;s:8:"nickname";s:4:"root";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:11:"description";s:0:"";s:12:"rich_editing";s:4:"true";s:19:"syntax_highlighting";s:4:"true";s:17:"comment_shortcuts";s:5:"false";s:11:"admin_color";s:5:"fresh";s:7:"use_ssl";s:1:"0";s:20:"show_admin_bar_front";s:5:"false";s:6:"locale";s:0:"";s:18:"show_welcome_panel";s:1:"1";s:37:"wp_dashboard_quick_press_last_post_id";s:1:"4";s:25:"community-events-location";s:33:"a:1:{s:2:"ip";s:10:"172.19.0.0";}";s:14:"account_status";s:8:"approved";s:24:"um_member_directory_data";s:137:"a:5:{s:14:"account_status";s:8:"approved";s:15:"hide_in_members";b:0;s:13:"profile_photo";b:0;s:11:"cover_photo";b:0;s:8:"verified";b:0;}";s:19:"account_status_name";s:8:"Approved";s:4:"role";s:13:"administrator";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:18:"can_access_wpadmin";i:1;s:20:"can_not_see_adminbar";i:0;s:17:"can_edit_everyone";i:1;s:19:"can_delete_everyone";i:1;s:16:"can_edit_profile";i:1;s:18:"can_delete_profile";i:1;s:16:"default_homepage";i:1;s:11:"after_login";s:14:"redirect_admin";s:12:"after_logout";s:13:"redirect_home";s:12:"can_view_all";i:1;s:24:"can_make_private_profile";i:1;s:26:"can_access_private_profile";i:1;s:6:"status";s:8:"approved";s:16:"auto_approve_act";s:16:"redirect_profile";s:11:"super_admin";i:1;}', 'no'),
(936, 'category_children', 'a:0:{}', 'yes'),
(1064, 'um_cached_users_queue', '0', 'no'),
(1071, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1636149322;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=562 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(21, 7, '_edit_lock', '1628349710:1'),
(22, 9, '_edit_lock', '1628601431:1'),
(32, 12, '_menu_item_type', 'post_type'),
(33, 12, '_menu_item_menu_item_parent', '0'),
(34, 12, '_menu_item_object_id', '7'),
(35, 12, '_menu_item_object', 'page'),
(36, 12, '_menu_item_target', ''),
(37, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(38, 12, '_menu_item_xfn', ''),
(39, 12, '_menu_item_url', ''),
(41, 13, '_menu_item_type', 'post_type'),
(42, 13, '_menu_item_menu_item_parent', '0'),
(43, 13, '_menu_item_object_id', '9'),
(44, 13, '_menu_item_object', 'page'),
(45, 13, '_menu_item_target', ''),
(46, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(47, 13, '_menu_item_xfn', ''),
(48, 13, '_menu_item_url', ''),
(50, 14, '_menu_item_type', 'post_type'),
(51, 14, '_menu_item_menu_item_parent', '0'),
(52, 14, '_menu_item_object_id', '2'),
(53, 14, '_menu_item_object', 'page'),
(54, 14, '_menu_item_target', ''),
(55, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(56, 14, '_menu_item_xfn', ''),
(57, 14, '_menu_item_url', ''),
(59, 15, '_wp_attached_file', '2021/07/asset-olive.png'),
(60, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:224;s:6:"height";i:48;s:4:"file";s:23:"2021/07/asset-olive.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"asset-olive-150x48.png";s:5:"width";i:150;s:6:"height";i:48;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(61, 16, '_wp_attached_file', '2021/07/asset-olive@2x.png'),
(62, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:448;s:6:"height";i:96;s:4:"file";s:26:"2021/07/asset-olive@2x.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:25:"asset-olive@2x-300x64.png";s:5:"width";i:300;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"asset-olive@2x-150x96.png";s:5:"width";i:150;s:6:"height";i:96;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(63, 17, '_wp_attached_file', '2021/07/asset-olive@3x.png'),
(64, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:672;s:6:"height";i:144;s:4:"file";s:26:"2021/07/asset-olive@3x.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:25:"asset-olive@3x-300x64.png";s:5:"width";i:300;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:26:"asset-olive@3x-150x144.png";s:5:"width";i:150;s:6:"height";i:144;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(65, 3, '_wp_trash_meta_status', 'draft'),
(66, 3, '_wp_trash_meta_time', '1625831589'),
(67, 3, '_wp_desired_post_slug', 'privacy-policy'),
(68, 19, '_edit_lock', '1625831857:1'),
(69, 21, '_edit_lock', '1628765097:1'),
(70, 19, '_wp_trash_meta_status', 'publish'),
(71, 19, '_wp_trash_meta_time', '1625832035'),
(72, 19, '_wp_desired_post_slug', 'education'),
(73, 23, '_edit_lock', '1628026634:1'),
(74, 2, '_edit_lock', '1627790230:1'),
(75, 26, '_menu_item_type', 'post_type'),
(76, 26, '_menu_item_menu_item_parent', '0'),
(77, 26, '_menu_item_object_id', '23'),
(78, 26, '_menu_item_object', 'page'),
(79, 26, '_menu_item_target', ''),
(80, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(81, 26, '_menu_item_xfn', ''),
(82, 26, '_menu_item_url', ''),
(84, 27, '_menu_item_type', 'post_type'),
(85, 27, '_menu_item_menu_item_parent', '0'),
(86, 27, '_menu_item_object_id', '21'),
(87, 27, '_menu_item_object', 'page'),
(88, 27, '_menu_item_target', ''),
(89, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(90, 27, '_menu_item_xfn', ''),
(91, 27, '_menu_item_url', ''),
(94, 12, '_wp_old_date', '2021-07-08'),
(95, 13, '_wp_old_date', '2021-07-08'),
(96, 14, '_wp_old_date', '2021-07-08'),
(98, 12, '_wp_old_date', '2021-07-09'),
(99, 13, '_wp_old_date', '2021-07-09'),
(100, 27, '_wp_old_date', '2021-07-09'),
(101, 26, '_wp_old_date', '2021-07-09'),
(102, 14, '_wp_old_date', '2021-07-09'),
(130, 31, '_menu_item_type', 'post_type'),
(131, 31, '_menu_item_menu_item_parent', '0'),
(132, 31, '_menu_item_object_id', '21'),
(133, 31, '_menu_item_object', 'page'),
(134, 31, '_menu_item_target', ''),
(135, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(136, 31, '_menu_item_xfn', ''),
(137, 31, '_menu_item_url', ''),
(139, 32, '_edit_lock', '1632300249:1'),
(140, 34, '_edit_lock', '1632498064:1'),
(141, 36, '_edit_lock', '1632300290:1'),
(142, 38, '_menu_item_type', 'post_type'),
(143, 38, '_menu_item_menu_item_parent', '13'),
(144, 38, '_menu_item_object_id', '36'),
(145, 38, '_menu_item_object', 'page'),
(146, 38, '_menu_item_target', ''),
(147, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(148, 38, '_menu_item_xfn', ''),
(149, 38, '_menu_item_url', ''),
(160, 40, '_menu_item_type', 'post_type'),
(161, 40, '_menu_item_menu_item_parent', '13'),
(162, 40, '_menu_item_object_id', '32'),
(163, 40, '_menu_item_object', 'page'),
(164, 40, '_menu_item_target', ''),
(165, 40, '_menu_item_classes', 'a:1:{i:0;s:16:"dropdown-submenu";}'),
(166, 40, '_menu_item_xfn', ''),
(167, 40, '_menu_item_url', ''),
(168, 1, '_edit_lock', '1627124192:1'),
(169, 1, '_pingme', '1'),
(170, 1, '_encloseme', '1'),
(171, 1, '_wp_trash_meta_status', 'publish'),
(172, 1, '_wp_trash_meta_time', '1627124370') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(173, 1, '_wp_desired_post_slug', 'hello-world'),
(174, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(175, 9, '_wp_page_template', 'default'),
(176, 47, '_wp_trash_meta_status', 'publish'),
(177, 47, '_wp_trash_meta_time', '1627288352'),
(178, 48, '_wp_trash_meta_status', 'publish'),
(179, 48, '_wp_trash_meta_time', '1627288367'),
(180, 49, '_edit_lock', '1627288398:1'),
(181, 49, '_customize_restore_dismissed', '1'),
(191, 12, '_wp_old_date', '2021-07-10'),
(192, 13, '_wp_old_date', '2021-07-10'),
(193, 27, '_wp_old_date', '2021-07-10'),
(194, 26, '_wp_old_date', '2021-07-10'),
(195, 14, '_wp_old_date', '2021-07-10'),
(196, 40, '_wp_old_date', '2021-07-10'),
(198, 38, '_wp_old_date', '2021-07-10'),
(199, 32, '_edit_last', '1'),
(200, 32, '_wp_page_template', 'default'),
(201, 34, '_edit_last', '1'),
(202, 34, '_wp_page_template', 'page-templates/login-page.php'),
(203, 36, '_edit_last', '1'),
(204, 36, '_wp_page_template', 'default'),
(205, 21, '_wp_page_template', 'default'),
(206, 23, '_wp_page_template', ''),
(207, 12, '_wp_old_date', '2021-07-26'),
(208, 13, '_wp_old_date', '2021-07-26'),
(209, 40, '_wp_old_date', '2021-07-26'),
(211, 38, '_wp_old_date', '2021-07-26'),
(212, 27, '_wp_old_date', '2021-07-26'),
(213, 26, '_wp_old_date', '2021-07-26'),
(214, 14, '_wp_old_date', '2021-07-26'),
(215, 52, '_edit_lock', '1628765750:1'),
(216, 53, '_menu_item_type', 'post_type'),
(217, 53, '_menu_item_menu_item_parent', '26'),
(218, 53, '_menu_item_object_id', '52'),
(219, 53, '_menu_item_object', 'page'),
(220, 53, '_menu_item_target', ''),
(221, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(222, 53, '_menu_item_xfn', ''),
(223, 53, '_menu_item_url', ''),
(224, 52, '_wp_page_template', 'default'),
(225, 55, '_edit_lock', '1628064222:1'),
(226, 56, '_menu_item_type', 'post_type'),
(227, 56, '_menu_item_menu_item_parent', '26'),
(228, 56, '_menu_item_object_id', '55'),
(229, 56, '_menu_item_object', 'page'),
(230, 56, '_menu_item_target', ''),
(231, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(232, 56, '_menu_item_xfn', ''),
(233, 56, '_menu_item_url', ''),
(234, 55, '_wp_page_template', 'page-templates/trading-page.php'),
(235, 58, '_edit_lock', '1628765730:1'),
(236, 59, '_menu_item_type', 'post_type'),
(237, 59, '_menu_item_menu_item_parent', '26'),
(238, 59, '_menu_item_object_id', '58'),
(239, 59, '_menu_item_object', 'page'),
(240, 59, '_menu_item_target', ''),
(241, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(242, 59, '_menu_item_xfn', ''),
(243, 59, '_menu_item_url', ''),
(244, 58, '_wp_page_template', 'default'),
(272, 23, '_edit_last', '1'),
(273, 52, '_edit_last', '1'),
(274, 69, '_wp_attached_file', '2021/07/Group-4.png'),
(275, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:681;s:6:"height";i:406;s:4:"file";s:19:"2021/07/Group-4.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:19:"Group-4-300x179.png";s:5:"width";i:300;s:6:"height";i:179;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"Group-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(276, 9, '_edit_last', '1'),
(277, 86, '_edit_lock', '1627863957:1'),
(278, 86, '_pingme', '1'),
(279, 86, '_encloseme', '1'),
(280, 2, '_edit_last', '1'),
(281, 86, '_edit_last', '1'),
(282, 86, '_wp_old_slug', 'up-to-100-rebate-bonus'),
(283, 58, '_edit_last', '1'),
(284, 55, '_edit_last', '1'),
(285, 7, '_edit_last', '1'),
(286, 7, '_wp_page_template', 'page-templates/template-home.php'),
(287, 21, '_edit_last', '1'),
(288, 112, '_edit_lock', '1629669385:1'),
(289, 113, '_edit_lock', '1634361311:1'),
(290, 113, '_pingme', '1'),
(291, 113, '_encloseme', '1'),
(292, 116, '_edit_lock', '1631570492:1'),
(301, 119, '_edit_lock', '1631571192:1'),
(310, 119, '_edit_last', '1'),
(311, 119, '_wp_page_template', 'page-templates/user-portal.php'),
(312, 12, '_wp_old_date', '2021-07-28'),
(313, 13, '_wp_old_date', '2021-07-28'),
(314, 40, '_wp_old_date', '2021-07-28'),
(316, 38, '_wp_old_date', '2021-07-28'),
(317, 27, '_wp_old_date', '2021-07-28'),
(318, 26, '_wp_old_date', '2021-07-28'),
(319, 56, '_wp_old_date', '2021-07-28'),
(320, 53, '_wp_old_date', '2021-07-28'),
(321, 59, '_wp_old_date', '2021-07-28'),
(322, 14, '_wp_old_date', '2021-07-28'),
(323, 125, '_edit_lock', '1632300197:1'),
(324, 127, '_edit_lock', '1632300236:1'),
(325, 129, '_menu_item_type', 'post_type'),
(326, 129, '_menu_item_menu_item_parent', '13'),
(327, 129, '_menu_item_object_id', '127') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(328, 129, '_menu_item_object', 'page'),
(329, 129, '_menu_item_target', ''),
(330, 129, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(331, 129, '_menu_item_xfn', ''),
(332, 129, '_menu_item_url', ''),
(334, 130, '_menu_item_type', 'post_type'),
(335, 130, '_menu_item_menu_item_parent', '13'),
(336, 130, '_menu_item_object_id', '125'),
(337, 130, '_menu_item_object', 'page'),
(338, 130, '_menu_item_target', ''),
(339, 130, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(340, 130, '_menu_item_xfn', ''),
(341, 130, '_menu_item_url', ''),
(343, 131, '_edit_lock', '1632300404:1'),
(344, 12, '_wp_old_date', '2021-09-14'),
(345, 13, '_wp_old_date', '2021-09-14'),
(346, 40, '_wp_old_date', '2021-09-14'),
(348, 38, '_wp_old_date', '2021-09-14'),
(349, 27, '_wp_old_date', '2021-09-14'),
(350, 26, '_wp_old_date', '2021-09-14'),
(351, 56, '_wp_old_date', '2021-09-14'),
(352, 53, '_wp_old_date', '2021-09-14'),
(353, 59, '_wp_old_date', '2021-09-14'),
(354, 14, '_wp_old_date', '2021-09-14'),
(355, 133, '_menu_item_type', 'post_type'),
(356, 133, '_menu_item_menu_item_parent', '146'),
(357, 133, '_menu_item_object_id', '131'),
(358, 133, '_menu_item_object', 'page'),
(359, 133, '_menu_item_target', ''),
(360, 133, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(361, 133, '_menu_item_xfn', ''),
(362, 133, '_menu_item_url', ''),
(364, 134, '_edit_lock', '1632301350:1'),
(365, 136, '_menu_item_type', 'post_type'),
(366, 136, '_menu_item_menu_item_parent', '40'),
(367, 136, '_menu_item_object_id', '134'),
(368, 136, '_menu_item_object', 'page'),
(369, 136, '_menu_item_target', ''),
(370, 136, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(371, 136, '_menu_item_xfn', ''),
(372, 136, '_menu_item_url', ''),
(374, 137, '_menu_item_type', 'post_type'),
(375, 137, '_menu_item_menu_item_parent', '146'),
(376, 137, '_menu_item_object_id', '113'),
(377, 137, '_menu_item_object', 'post'),
(378, 137, '_menu_item_target', ''),
(379, 137, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(380, 137, '_menu_item_xfn', ''),
(381, 137, '_menu_item_url', ''),
(383, 12, '_wp_old_date', '2021-09-22'),
(384, 13, '_wp_old_date', '2021-09-22'),
(385, 40, '_wp_old_date', '2021-09-22'),
(386, 136, '_wp_old_date', '2021-09-22'),
(388, 137, '_wp_old_date', '2021-09-22'),
(389, 133, '_wp_old_date', '2021-09-22'),
(390, 38, '_wp_old_date', '2021-09-22'),
(391, 130, '_wp_old_date', '2021-09-22'),
(392, 129, '_wp_old_date', '2021-09-22'),
(393, 27, '_wp_old_date', '2021-09-22'),
(394, 26, '_wp_old_date', '2021-09-22'),
(395, 56, '_wp_old_date', '2021-09-22'),
(396, 53, '_wp_old_date', '2021-09-22'),
(397, 59, '_wp_old_date', '2021-09-22'),
(398, 14, '_wp_old_date', '2021-09-22'),
(399, 138, '_um_custom_fields', 'a:6:{s:10:"user_login";a:15:{s:5:"title";s:8:"Username";s:7:"metakey";s:10:"user_login";s:4:"type";s:4:"text";s:5:"label";s:8:"Username";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:0;s:8:"validate";s:15:"unique_username";s:9:"min_chars";i:3;s:9:"max_chars";i:24;s:8:"position";s:1:"1";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:10:"user_email";a:13:{s:5:"title";s:14:"E-mail Address";s:7:"metakey";s:10:"user_email";s:4:"type";s:4:"text";s:5:"label";s:14:"E-mail Address";s:8:"required";i:0;s:6:"public";i:1;s:8:"editable";i:1;s:8:"validate";s:12:"unique_email";s:8:"position";s:1:"4";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:13:"user_password";a:16:{s:5:"title";s:8:"Password";s:7:"metakey";s:13:"user_password";s:4:"type";s:8:"password";s:5:"label";s:8:"Password";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:1;s:9:"min_chars";i:8;s:9:"max_chars";i:30;s:15:"force_good_pass";i:1;s:18:"force_confirm_pass";i:1;s:8:"position";s:1:"5";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:10:"first_name";a:12:{s:5:"title";s:10:"First Name";s:7:"metakey";s:10:"first_name";s:4:"type";s:4:"text";s:5:"label";s:10:"First Name";s:8:"required";i:0;s:6:"public";i:1;s:8:"editable";i:1;s:8:"position";s:1:"2";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:9:"last_name";a:12:{s:5:"title";s:9:"Last Name";s:7:"metakey";s:9:"last_name";s:4:"type";s:4:"text";s:5:"label";s:9:"Last Name";s:8:"required";i:0;s:6:"public";i:1;s:8:"editable";i:1;s:8:"position";s:1:"3";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:9:"_um_row_1";a:4:{s:4:"type";s:3:"row";s:2:"id";s:9:"_um_row_1";s:8:"sub_rows";s:1:"1";s:4:"cols";s:1:"1";}}'),
(400, 138, '_um_mode', 'register'),
(401, 138, '_um_core', 'register'),
(402, 138, '_um_register_use_custom_settings', '0'),
(403, 139, '_um_custom_fields', 'a:3:{s:8:"username";a:13:{s:5:"title";s:18:"Username or E-mail";s:7:"metakey";s:8:"username";s:4:"type";s:4:"text";s:5:"label";s:18:"Username or E-mail";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:0;s:8:"validate";s:24:"unique_username_or_email";s:8:"position";s:1:"1";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:13:"user_password";a:16:{s:5:"title";s:8:"Password";s:7:"metakey";s:13:"user_password";s:4:"type";s:8:"password";s:5:"label";s:8:"Password";s:8:"required";i:1;s:6:"public";i:1;s:8:"editable";i:1;s:9:"min_chars";i:8;s:9:"max_chars";i:30;s:15:"force_good_pass";i:1;s:18:"force_confirm_pass";i:1;s:8:"position";s:1:"2";s:6:"in_row";s:9:"_um_row_1";s:10:"in_sub_row";s:1:"0";s:9:"in_column";s:1:"1";s:8:"in_group";s:0:"";}s:9:"_um_row_1";a:4:{s:4:"type";s:3:"row";s:2:"id";s:9:"_um_row_1";s:8:"sub_rows";s:1:"1";s:4:"cols";s:1:"1";}}'),
(404, 139, '_um_mode', 'login'),
(405, 139, '_um_core', 'login'),
(406, 139, '_um_login_use_custom_settings', '0'),
(407, 140, '_um_custom_fields', 'a:1:{s:9:"_um_row_1";a:4:{s:4:"type";s:3:"row";s:2:"id";s:9:"_um_row_1";s:8:"sub_rows";s:1:"1";s:4:"cols";s:1:"1";}}'),
(408, 140, '_um_mode', 'profile'),
(409, 140, '_um_core', 'profile'),
(410, 140, '_um_profile_use_custom_settings', '0'),
(411, 141, '_um_core', 'members'),
(412, 141, '_um_template', 'members'),
(413, 141, '_um_mode', 'directory'),
(414, 141, '_um_view_types', 'a:1:{i:0;s:4:"grid";}'),
(415, 141, '_um_default_view', 'grid'),
(416, 141, '_um_roles', 'a:0:{}'),
(417, 141, '_um_has_profile_photo', '0'),
(418, 141, '_um_has_cover_photo', '0'),
(419, 141, '_um_show_these_users', ''),
(420, 141, '_um_exclude_these_users', ''),
(421, 141, '_um_sortby', 'user_registered_desc'),
(422, 141, '_um_sortby_custom', ''),
(423, 141, '_um_sortby_custom_label', ''),
(424, 141, '_um_enable_sorting', '0'),
(425, 141, '_um_sorting_fields', 'a:0:{}'),
(426, 141, '_um_profile_photo', '1'),
(427, 141, '_um_cover_photos', '1'),
(428, 141, '_um_show_name', '1'),
(429, 141, '_um_show_tagline', '0'),
(430, 141, '_um_tagline_fields', 'a:0:{}'),
(431, 141, '_um_show_userinfo', '0'),
(432, 141, '_um_reveal_fields', 'a:0:{}'),
(433, 141, '_um_show_social', '0'),
(434, 141, '_um_userinfo_animate', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(435, 141, '_um_search', '0'),
(436, 141, '_um_roles_can_search', 'a:0:{}'),
(437, 141, '_um_filters', '0'),
(438, 141, '_um_roles_can_filter', 'a:0:{}'),
(439, 141, '_um_search_fields', 'a:0:{}'),
(440, 141, '_um_filters_expanded', '0'),
(441, 141, '_um_filters_is_collapsible', '1'),
(442, 141, '_um_search_filters', 'a:0:{}'),
(443, 141, '_um_must_search', '0'),
(444, 141, '_um_max_users', ''),
(445, 141, '_um_profiles_per_page', '12'),
(446, 141, '_um_profiles_per_page_mobile', '6'),
(447, 141, '_um_directory_header', '{total_users} Members'),
(448, 141, '_um_directory_header_single', '{total_users} Member'),
(449, 141, '_um_directory_no_users', 'We are sorry. We cannot find any users who match your search criteria.'),
(450, 34, 'um_content_restriction', 'a:8:{s:26:"_um_custom_access_settings";b:0;s:14:"_um_accessible";i:0;s:28:"_um_access_hide_from_queries";b:0;s:19:"_um_noaccess_action";i:0;s:30:"_um_restrict_by_custom_message";i:0;s:27:"_um_restrict_custom_message";s:0:"";s:19:"_um_access_redirect";i:0;s:23:"_um_access_redirect_url";s:0:"";}'),
(451, 143, '_edit_lock', '1634361030:1'),
(452, 143, '_pingme', '1'),
(453, 143, '_encloseme', '1'),
(454, 143, '_edit_last', '1'),
(455, 143, 'um_content_restriction', 'a:8:{s:26:"_um_custom_access_settings";b:0;s:14:"_um_accessible";i:0;s:28:"_um_access_hide_from_queries";b:0;s:19:"_um_noaccess_action";i:0;s:30:"_um_restrict_by_custom_message";i:0;s:27:"_um_restrict_custom_message";s:0:"";s:19:"_um_access_redirect";i:0;s:23:"_um_access_redirect_url";s:0:"";}'),
(456, 145, '_menu_item_type', 'post_type'),
(457, 145, '_menu_item_menu_item_parent', '0'),
(458, 145, '_menu_item_object_id', '143'),
(459, 145, '_menu_item_object', 'post'),
(460, 145, '_menu_item_target', ''),
(461, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(462, 145, '_menu_item_xfn', ''),
(463, 145, '_menu_item_url', ''),
(464, 145, '_menu_item_orphaned', '1634356082'),
(465, 146, '_menu_item_type', 'post_type'),
(466, 146, '_menu_item_menu_item_parent', '13'),
(467, 146, '_menu_item_object_id', '143'),
(468, 146, '_menu_item_object', 'post'),
(469, 146, '_menu_item_target', ''),
(470, 146, '_menu_item_classes', 'a:1:{i:0;s:16:"dropdown-submenu";}'),
(471, 146, '_menu_item_xfn', ''),
(472, 146, '_menu_item_url', ''),
(474, 12, '_wp_old_date', '2021-09-23'),
(475, 13, '_wp_old_date', '2021-09-23'),
(476, 40, '_wp_old_date', '2021-09-23'),
(477, 136, '_wp_old_date', '2021-09-23'),
(478, 137, '_wp_old_date', '2021-09-23'),
(479, 133, '_wp_old_date', '2021-09-23'),
(480, 38, '_wp_old_date', '2021-09-23'),
(481, 130, '_wp_old_date', '2021-09-23'),
(482, 129, '_wp_old_date', '2021-09-23'),
(483, 27, '_wp_old_date', '2021-09-23'),
(484, 26, '_wp_old_date', '2021-09-23'),
(485, 56, '_wp_old_date', '2021-09-23'),
(486, 53, '_wp_old_date', '2021-09-23'),
(487, 59, '_wp_old_date', '2021-09-23'),
(488, 14, '_wp_old_date', '2021-09-23'),
(489, 147, '_edit_lock', '1634361181:1'),
(490, 148, '_edit_lock', '1634405893:1'),
(491, 150, '_menu_item_type', 'post_type'),
(492, 150, '_menu_item_menu_item_parent', '0'),
(493, 150, '_menu_item_object_id', '149'),
(494, 150, '_menu_item_object', 'page'),
(495, 150, '_menu_item_target', ''),
(496, 150, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(497, 150, '_menu_item_xfn', ''),
(498, 150, '_menu_item_url', ''),
(500, 152, '_menu_item_type', 'post_type'),
(501, 152, '_menu_item_menu_item_parent', '0'),
(502, 152, '_menu_item_object_id', '151'),
(503, 152, '_menu_item_object', 'page'),
(504, 152, '_menu_item_target', ''),
(505, 152, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(506, 152, '_menu_item_xfn', ''),
(507, 152, '_menu_item_url', ''),
(509, 154, '_menu_item_type', 'post_type'),
(510, 154, '_menu_item_menu_item_parent', '0'),
(511, 154, '_menu_item_object_id', '153'),
(512, 154, '_menu_item_object', 'page'),
(513, 154, '_menu_item_target', ''),
(514, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(515, 154, '_menu_item_xfn', ''),
(516, 154, '_menu_item_url', ''),
(518, 156, '_menu_item_type', 'post_type'),
(519, 156, '_menu_item_menu_item_parent', '0'),
(520, 156, '_menu_item_object_id', '155'),
(521, 156, '_menu_item_object', 'page'),
(522, 156, '_menu_item_target', ''),
(523, 156, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(524, 156, '_menu_item_xfn', ''),
(525, 156, '_menu_item_url', ''),
(527, 158, '_menu_item_type', 'post_type'),
(528, 158, '_menu_item_menu_item_parent', '0'),
(529, 158, '_menu_item_object_id', '157'),
(530, 158, '_menu_item_object', 'page'),
(531, 158, '_menu_item_target', ''),
(532, 158, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(533, 158, '_menu_item_xfn', ''),
(534, 158, '_menu_item_url', ''),
(536, 160, '_menu_item_type', 'post_type'),
(537, 160, '_menu_item_menu_item_parent', '0'),
(538, 160, '_menu_item_object_id', '159'),
(539, 160, '_menu_item_object', 'page'),
(540, 160, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(541, 160, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(542, 160, '_menu_item_xfn', ''),
(543, 160, '_menu_item_url', ''),
(545, 162, '_menu_item_type', 'post_type'),
(546, 162, '_menu_item_menu_item_parent', '0'),
(547, 162, '_menu_item_object_id', '161'),
(548, 162, '_menu_item_object', 'page'),
(549, 162, '_menu_item_target', ''),
(550, 162, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(551, 162, '_menu_item_xfn', ''),
(552, 162, '_menu_item_url', ''),
(554, 1, '_um_core', 'pages_settings'),
(555, 149, '_um_core', 'user'),
(556, 151, '_um_core', 'login'),
(557, 153, '_um_core', 'register'),
(558, 155, '_um_core', 'members'),
(559, 157, '_um_core', 'logout'),
(560, 159, '_um_core', 'account'),
(561, 161, '_um_core', 'password-reset') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-07-07 13:59:24', '2021-07-07 13:59:24', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world! test', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2021-07-24 10:59:30', '2021-07-24 10:59:30', '', 0, 'http://localhost:8000/?p=1', 0, 'post', '', 1),
(2, 1, '2021-07-07 13:59:24', '2021-07-07 13:59:24', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:&lt;/p></code></pre>\n<!-- /wp:code -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8000/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Partners', '', 'publish', 'closed', 'closed', '', 'partners', '', '', '2021-08-01 03:57:09', '2021-08-01 03:57:09', '', 0, 'http://localhost:8000/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-07-07 13:59:24', '2021-07-07 13:59:24', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:8000.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2021-07-09 11:53:09', '2021-07-09 11:53:09', '', 0, 'http://localhost:8000/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-07-07 13:59:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-07-07 13:59:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=4', 0, 'post', '', 0),
(7, 1, '2021-07-08 07:11:12', '2021-07-08 07:11:12', '', 'Company', '', 'publish', 'closed', 'closed', '', 'company', '', '', '2021-08-07 13:31:40', '2021-08-07 13:31:40', '', 0, 'http://localhost:8000/?page_id=7', 0, 'page', '', 0),
(8, 1, '2021-07-08 07:11:12', '2021-07-08 07:11:12', '', 'Company', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-07-08 07:11:12', '2021-07-08 07:11:12', '', 7, 'http://localhost:8000/?p=8', 0, 'revision', '', 0),
(9, 1, '2021-07-08 07:12:07', '2021-07-08 07:12:07', '<!-- wp:html -->\n<div class="custom-header-bg">\n    <div class="container">\n        <div class="row">\n            <div class="col-md-12">\n                <div class="header-container">\n                    <div class="header-banner">\n                        <h2 class="primary-header">Three <span class="orng-span">Account Types</span>. Same Great Service!</h2>\n                        <p class="subheading">Investing has never been easier. Everything you are looking for in an ultimate investment platform — on the device of your choice.</p>\n                        <a href="#" class="stocks-button">Forex</a>\n                        <a href="#" class="stocks-button">Stocks</a>\n                        <a href="#" class="stocks-button">Indices</a>\n                        <a href="#" class="stocks-button">Commodities</a>\n                        <a href="#" class="stocks-button">Crypto</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n<!-- /wp:html -->', 'Markets', '', 'publish', 'closed', 'closed', '', 'markets', '', '', '2021-08-07 17:07:22', '2021-08-07 17:07:22', '', 0, 'http://localhost:8000/?page_id=9', 1, 'page', '', 0),
(10, 1, '2021-07-08 07:12:07', '2021-07-08 07:12:07', '', 'Markets', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2021-07-08 07:12:07', '2021-07-08 07:12:07', '', 9, 'http://localhost:8000/?p=10', 0, 'revision', '', 0),
(12, 1, '2021-10-16 03:51:04', '2021-07-08 07:12:47', ' ', '', '', 'publish', 'closed', 'closed', '', '12', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=12', 1, 'nav_menu_item', '', 0),
(13, 1, '2021-10-16 03:51:04', '2021-07-08 07:12:47', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=13', 2, 'nav_menu_item', '', 0),
(14, 1, '2021-10-16 03:51:04', '2021-07-08 07:12:47', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=14', 16, 'nav_menu_item', '', 0),
(15, 1, '2021-07-08 11:10:20', '2021-07-08 11:10:20', '', 'asset-olive', '', 'inherit', 'open', 'closed', '', 'asset-olive', '', '', '2021-07-08 11:10:20', '2021-07-08 11:10:20', '', 0, 'http://localhost:8000/wp-content/uploads/2021/07/asset-olive.png', 0, 'attachment', 'image/png', 0),
(16, 1, '2021-07-08 11:10:20', '2021-07-08 11:10:20', '', 'asset-olive@2x', '', 'inherit', 'open', 'closed', '', 'asset-olive2x', '', '', '2021-07-08 11:10:20', '2021-07-08 11:10:20', '', 0, 'http://localhost:8000/wp-content/uploads/2021/07/asset-olive@2x.png', 0, 'attachment', 'image/png', 0),
(17, 1, '2021-07-08 11:10:21', '2021-07-08 11:10:21', '', 'asset-olive@3x', '', 'inherit', 'open', 'closed', '', 'asset-olive3x', '', '', '2021-07-08 11:10:21', '2021-07-08 11:10:21', '', 0, 'http://localhost:8000/wp-content/uploads/2021/07/asset-olive@3x.png', 0, 'attachment', 'image/png', 0),
(18, 1, '2021-07-09 11:53:09', '2021-07-09 11:53:09', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:8000.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2021-07-09 11:53:09', '2021-07-09 11:53:09', '', 3, 'http://localhost:8000/?p=18', 0, 'revision', '', 0),
(19, 1, '2021-07-09 11:59:52', '2021-07-09 11:59:52', '', 'Education', '', 'trash', 'closed', 'closed', '', 'education__trashed', '', '', '2021-07-09 12:00:35', '2021-07-09 12:00:35', '', 0, 'http://localhost:8000/?page_id=19', 0, 'page', '', 0),
(20, 1, '2021-07-09 11:59:52', '2021-07-09 11:59:52', '', 'Education', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2021-07-09 11:59:52', '2021-07-09 11:59:52', '', 19, 'http://localhost:8000/?p=20', 0, 'revision', '', 0),
(21, 1, '2021-07-09 12:00:16', '2021-07-09 12:00:16', '', 'Education', '', 'publish', 'closed', 'closed', '', 'education', '', '', '2021-08-12 10:44:56', '2021-08-12 10:44:56', '', 0, 'http://localhost:8000/?page_id=21', 0, 'page', '', 0),
(22, 1, '2021-07-09 12:00:16', '2021-07-09 12:00:16', '', 'Education', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2021-07-09 12:00:16', '2021-07-09 12:00:16', '', 21, 'http://localhost:8000/?p=22', 0, 'revision', '', 0),
(23, 1, '2021-07-09 12:01:08', '2021-07-09 12:01:08', '', 'Trading', '', 'publish', 'closed', 'closed', '', 'trading', '', '', '2021-07-28 22:00:09', '2021-07-28 22:00:09', '', 0, 'http://localhost:8000/?page_id=23', 0, 'page', '', 0),
(24, 1, '2021-07-09 12:01:08', '2021-07-09 12:01:08', '', 'Trading', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2021-07-09 12:01:08', '2021-07-09 12:01:08', '', 23, 'http://localhost:8000/?p=24', 0, 'revision', '', 0),
(25, 1, '2021-07-09 12:02:12', '2021-07-09 12:02:12', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8000/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Partners', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-07-09 12:02:12', '2021-07-09 12:02:12', '', 2, 'http://localhost:8000/?p=25', 0, 'revision', '', 0),
(26, 1, '2021-10-16 03:51:04', '2021-07-09 12:04:26', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=26', 12, 'nav_menu_item', '', 0),
(27, 1, '2021-10-16 03:51:04', '2021-07-09 12:04:26', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=27', 11, 'nav_menu_item', '', 0),
(31, 1, '2021-07-10 19:54:15', '2021-07-10 19:54:15', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2021-07-10 19:54:15', '2021-07-10 19:54:15', '', 0, 'http://localhost:8000/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2021-07-10 22:53:43', '2021-07-10 22:53:43', '', 'FX', '', 'publish', 'closed', 'closed', '', 'fx', '', '', '2021-09-22 08:44:08', '2021-09-22 08:44:08', '', 9, 'http://localhost:8000/?page_id=32', 0, 'page', '', 0),
(33, 1, '2021-07-10 22:53:43', '2021-07-10 22:53:43', '', 'Stock1', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-07-10 22:53:43', '2021-07-10 22:53:43', '', 32, 'http://localhost:8000/?p=33', 0, 'revision', '', 0),
(34, 1, '2021-07-10 22:54:03', '2021-07-10 22:54:03', '', 'Stocks', '', 'publish', 'closed', 'closed', '', 'stocks', '', '', '2021-09-24 09:10:42', '2021-09-24 09:10:42', '', 9, 'http://localhost:8000/?page_id=34', 0, 'page', '', 0),
(35, 1, '2021-07-10 22:54:03', '2021-07-10 22:54:03', '', 'Stock2', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2021-07-10 22:54:03', '2021-07-10 22:54:03', '', 34, 'http://localhost:8000/?p=35', 0, 'revision', '', 0),
(36, 1, '2021-07-10 22:54:18', '2021-07-10 22:54:18', '', 'Indices', '', 'publish', 'closed', 'closed', '', 'indices', '', '', '2021-09-22 08:44:49', '2021-09-22 08:44:49', '', 9, 'http://localhost:8000/?page_id=36', 0, 'page', '', 0),
(37, 1, '2021-07-10 22:54:18', '2021-07-10 22:54:18', '', 'Stock3', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2021-07-10 22:54:18', '2021-07-10 22:54:18', '', 36, 'http://localhost:8000/?p=37', 0, 'revision', '', 0),
(38, 1, '2021-10-16 03:51:04', '2021-07-10 22:55:27', '324 trading pairs', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 9, 'http://localhost:8000/?p=38', 8, 'nav_menu_item', '', 0),
(40, 1, '2021-10-16 03:51:04', '2021-07-10 22:55:27', '324 trading pairs', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 9, 'http://localhost:8000/?p=40', 3, 'nav_menu_item', '', 0),
(42, 1, '2021-07-24 10:58:54', '2021-07-24 10:58:54', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world! test', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2021-07-24 10:58:54', '2021-07-24 10:58:54', '', 1, 'http://localhost:8000/?p=42', 0, 'revision', '', 0),
(44, 1, '2021-07-25 11:52:27', '2021-07-25 11:52:27', '<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;!-- Start Kiobe App Section -->\r\n    &lt;section class="kiobe-app">\r\n        &lt;div class="container">\r\n            &lt;div class="row">\r\n                &lt;div class="col-md-12 kiobe-app-heading">\r\n                    &lt;h2 class="kiobe-app-title">&lt;span class="orng-span">The Kiobe app&lt;/span> is easy to use.&lt;/h2>\r\n                    &lt;div class="kiobe-app-subtitle">\r\n                        &lt;p>Perfect for both beginners and experts.&lt;/p>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n            &lt;div class="row kiobe-app-desktop">\r\n                &lt;div class="col-md-12 kiobe-app-body">\r\n                    &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/Group-27@2x.png" alt="" class="group-27">\r\n                    &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/iphone-screen@2x.png" alt="" class="TP">\r\n                &lt;/div>\r\n            &lt;/div>\r\n            &lt;!-- Kiobe App Section For Mobile -->\r\n            &lt;div class="row kiobe-app-mobile">\r\n                &lt;div class="col-md-12">\r\n                    &lt;div class="kiobe-app-img-slider">\r\n                        &lt;div class="kiobe-app-slide active-slide">\r\n                            &lt;div class="kiobe-app-body">\r\n                                &lt;div class="kiobe-app-info">\r\n                                    &lt;h3>Copy Trade&lt;/h3>\r\n                                    &lt;p>Trade like Kiobe’s top traders.&lt;/p>\r\n                                &lt;/div>\r\n                                &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/Group11@2x.png" alt="" class="TP">\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="kiobe-app-slide">\r\n                            &lt;div class="kiobe-app-body">\r\n                                &lt;div class="kiobe-app-info">\r\n                                    &lt;h3>Trading&lt;/h3>\r\n                                    &lt;p>Trade 70 currencies, shares, crypto and options.&lt;/p>\r\n                                &lt;/div>\r\n                                &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/Group11@2x.png" alt="" class="TP">\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="kiobe-app-slide">\r\n                            &lt;div class="kiobe-app-body">\r\n                                &lt;div class="kiobe-app-info">\r\n                                    &lt;h3>Settings&lt;/h3>\r\n                                    &lt;p>Many instruments for your trading.&lt;/p>\r\n                                &lt;/div>\r\n                                &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/Group11@2x.png" alt="" class="TP">\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="kiobe-app-slide">\r\n                            &lt;div class="kiobe-app-body">\r\n                                &lt;div class="kiobe-app-info">\r\n                                    &lt;h3>Position&lt;/h3>\r\n                                    &lt;p>Set Stop-Loss Points.Calculating Expected Return.&lt;/p>\r\n                                &lt;/div>\r\n                                &lt;img src="&lt;?php bloginfo(\'template_url\'); ?>/img/Group11@2x.png" alt="" class="TP">\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="kiobe-app-navigation">\r\n                            &lt;div class="kiobe-app-btn active-slide">&lt;/div>\r\n                            &lt;div class="kiobe-app-btn">&lt;/div>\r\n                            &lt;div class="kiobe-app-btn">&lt;/div>\r\n                            &lt;div class="kiobe-app-btn">&lt;/div>\r\n                        &lt;/div>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n        &lt;/div>\r\n    &lt;/section>\r\n&lt;!-- End Kiobe App Section --></code></pre>\n<!-- /wp:code -->', 'Company', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-07-25 11:52:27', '2021-07-25 11:52:27', '', 7, 'http://localhost:8000/?p=44', 0, 'revision', '', 0),
(45, 1, '2021-07-25 11:53:52', '2021-07-25 11:53:52', '', 'Company', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-07-25 11:53:52', '2021-07-25 11:53:52', '', 7, 'http://localhost:8000/?p=45', 0, 'revision', '', 0),
(47, 1, '2021-07-26 08:32:32', '2021-07-26 08:32:32', '{"Kiobe-Theme::nav_menu_locations[footer-menu]":{"value":2,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-07-26 08:32:32"}}', '', '', 'trash', 'closed', 'closed', '', 'de19a586-bc5d-43ed-9d1e-e27ab2b19eaf', '', '', '2021-07-26 08:32:32', '2021-07-26 08:32:32', '', 0, 'http://localhost:8000/uncategorized/de19a586-bc5d-43ed-9d1e-e27ab2b19eaf/', 0, 'customize_changeset', '', 0),
(48, 1, '2021-07-26 08:32:47', '2021-07-26 08:32:47', '{"Kiobe-Theme::nav_menu_locations[footer-menu]":{"value":0,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-07-26 08:32:47"}}', '', '', 'trash', 'closed', 'closed', '', '9d08b30a-1fcc-4579-a4ac-507556561173', '', '', '2021-07-26 08:32:47', '2021-07-26 08:32:47', '', 0, 'http://localhost:8000/uncategorized/9d08b30a-1fcc-4579-a4ac-507556561173/', 0, 'customize_changeset', '', 0),
(49, 1, '2021-07-26 08:33:18', '0000-00-00 00:00:00', '{"Kiobe-Theme::nav_menu_locations[bootstrap-menu]":{"value":4,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-07-26 08:33:18"},"Kiobe-Theme::nav_menu_locations[footer-menu]":{"value":0,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-07-26 08:33:18"}}', '', '', 'auto-draft', 'closed', 'closed', '', 'b1b08602-c8bc-43eb-818d-b2802ababba5', '', '', '2021-07-26 08:33:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=49', 0, 'customize_changeset', '', 0),
(52, 1, '2021-07-28 16:48:54', '2021-07-28 16:48:54', '<!-- wp:html /-->', 'Promotions', '', 'publish', 'closed', 'closed', '', 'promotions', '', '', '2021-08-12 10:55:49', '2021-08-12 10:55:49', '', 23, 'http://localhost:8000/?page_id=52', 0, 'page', '', 0),
(53, 1, '2021-10-16 03:51:04', '2021-07-28 16:48:54', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 23, 'http://localhost:8000/uncategorized/53/', 14, 'nav_menu_item', '', 0),
(54, 1, '2021-07-28 16:48:54', '2021-07-28 16:48:54', '', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-28 16:48:54', '2021-07-28 16:48:54', '', 52, 'http://localhost:8000/?p=54', 0, 'revision', '', 0),
(55, 1, '2021-07-28 17:41:05', '2021-07-28 17:41:05', '', 'Trading Tools', '', 'publish', 'closed', 'closed', '', 'trading-tools', '', '', '2021-08-04 08:03:42', '2021-08-04 08:03:42', '', 23, 'http://localhost:8000/?page_id=55', 0, 'page', '', 0),
(56, 1, '2021-10-16 03:51:04', '2021-07-28 17:41:05', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 23, 'http://localhost:8000/uncategorized/56/', 13, 'nav_menu_item', '', 0),
(57, 1, '2021-07-28 17:41:05', '2021-07-28 17:41:05', '', 'Trading Tools', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2021-07-28 17:41:05', '2021-07-28 17:41:05', '', 55, 'http://localhost:8000/?p=57', 0, 'revision', '', 0),
(58, 1, '2021-07-28 17:41:28', '2021-07-28 17:41:28', '', 'Account Types', '', 'publish', 'closed', 'closed', '', 'account-types', '', '', '2021-08-12 10:55:29', '2021-08-12 10:55:29', '', 23, 'http://localhost:8000/?page_id=58', 0, 'page', '', 0),
(59, 1, '2021-10-16 03:51:04', '2021-07-28 17:41:28', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 23, 'http://localhost:8000/uncategorized/59/', 15, 'nav_menu_item', '', 0),
(60, 1, '2021-07-28 17:41:28', '2021-07-28 17:41:28', '', 'Account Types', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2021-07-28 17:41:28', '2021-07-28 17:41:28', '', 58, 'http://localhost:8000/?p=60', 0, 'revision', '', 0),
(65, 1, '2021-07-28 18:22:32', '2021-07-28 18:22:32', '<!-- wp:code -->\n<pre class="wp-block-code"><code></code></pre>\n<!-- /wp:code -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-28 18:22:32', '2021-07-28 18:22:32', '', 52, 'http://localhost:8000/?p=65', 0, 'revision', '', 0),
(66, 1, '2021-07-28 18:30:19', '2021-07-28 18:30:19', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8000/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Partners', '', 'inherit', 'closed', 'closed', '', '2-autosave-v1', '', '', '2021-07-28 18:30:19', '2021-07-28 18:30:19', '', 2, 'http://localhost:8000/?p=66', 0, 'revision', '', 0),
(67, 1, '2021-07-28 18:25:56', '2021-07-28 18:25:56', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:&lt;/p></code></pre>\n<!-- /wp:code -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8000/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Partners', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-07-28 18:25:56', '2021-07-28 18:25:56', '', 2, 'http://localhost:8000/?p=67', 0, 'revision', '', 0),
(69, 1, '2021-07-31 02:58:51', '2021-07-31 02:58:51', '', 'Group 4', '', 'inherit', 'open', 'closed', '', 'group-4', '', '', '2021-07-31 02:58:51', '2021-07-31 02:58:51', '', 52, 'http://localhost:8000/wp-content/uploads/2021/07/Group-4.png', 0, 'attachment', 'image/png', 0),
(70, 1, '2021-07-31 03:00:15', '2021-07-31 03:00:15', '<!-- wp:image {"id":69,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69"/><figcaption>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. Claim your BONUS. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</figcaption></figure>\n<!-- /wp:image -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 03:00:15', '2021-07-31 03:00:15', '', 52, 'http://localhost:8000/?p=70', 0, 'revision', '', 0),
(71, 1, '2021-07-31 06:28:36', '2021-07-31 06:28:36', '<!-- wp:image {"id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. Claim your BONUS. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n<!-- /wp:paragraph -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:28:36', '2021-07-31 06:28:36', '', 52, 'http://localhost:8000/?p=71', 0, 'revision', '', 0),
(72, 1, '2021-07-31 06:29:51', '2021-07-31 06:29:51', '<!-- wp:image {"id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph {"className":"row promotions-mobile"} -->\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n<!-- /wp:paragraph -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:29:51', '2021-07-31 06:29:51', '', 52, 'http://localhost:8000/?p=72', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(74, 1, '2021-07-31 06:33:09', '2021-07-31 06:33:09', '<!-- wp:image {"id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:html -->\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n<!-- /wp:html -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;div class="promotions-container">\r\n    &lt;section class="refer-friend">\r\n        &lt;div class="container">\r\n            &lt;div class="row promotions-desktop">\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>&lt;span class="orng-span">Invite a friend&lt;/span>\r\n                        &lt;span class="subtext">And get &lt;span class="orng-span"> 50&lt;/span> tokens&lt;/h3>\r\n                        &lt;/h2>\r\n                        &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n                &lt;div class="col-md-5">\r\n                    &lt;h2>&lt;span class="orng-span">Refer&lt;/span> a friend&lt;/h2>\r\n                    &lt;p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. &lt;span class="orng-span">Claim your BONUS&lt;/span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.&lt;/p>\r\n                    &lt;p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the &lt;span class="orng-span"> terms of the Promotion &lt;/span>.&lt;/p>\r\n                &lt;/div>\r\n            &lt;/div>\r\n            &lt;div class="row promotions-mobile">\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>&lt;span class="orng-span">Invite a friend&lt;/span>\r\n                        &lt;span class="subtext">And get &lt;span class="orng-span"> 50&lt;/span> tokens&lt;/h3>\r\n                        &lt;/h2>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n                &lt;div class="col-md-6">\r\n                    &lt;p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. &lt;span class="orng-span">Claim your BONUS&lt;/span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.&lt;/p>\r\n                    &lt;p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the &lt;span class="orng-span"> terms of the Promotion &lt;/span>.&lt;/p>\r\n                    &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                &lt;/div>\r\n            &lt;/div>\r\n        &lt;/div>\r\n    &lt;/section>\r\n    &lt;section class="rebate-bonus">\r\n        &lt;div class="container">\r\n            &lt;div class="row promotions-desktop">\r\n                &lt;div class="col-md-5">\r\n                    &lt;h2>Up to 100% &lt;span class="orng-span">Rebate Bonus&lt;/span>&lt;/h2>\r\n                    &lt;p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\r\n                    Only few steps to get started:&lt;/p>\r\n                    &lt;p>Make a deposit into your trading account\r\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\r\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.&lt;/p>\r\n                &lt;/div>\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>Up to 100% &lt;span class="orng-span">Rebate Bonus&lt;/span>&lt;/h2>\r\n                        &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n            &lt;div class="row promotions-mobile">\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>Up to 100% &lt;span class="orng-span">Rebate Bonus&lt;/span>&lt;/h2>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n                &lt;div class="col-md-6">\r\n                    &lt;p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\r\n                    Only few steps to get started:&lt;/p>\r\n                    &lt;p>Make a deposit into your trading account\r\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\r\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.&lt;/p>\r\n                    &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                &lt;/div>\r\n            &lt;/div>\r\n        &lt;/div>\r\n    &lt;/section>\r\n    &lt;section class="interest-rate">\r\n        &lt;div class="container">\r\n            &lt;div class="row promotions-desktop">\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>10%  &lt;span class="orng-span">Interest Rate&lt;/span>&lt;/h2>\r\n                        &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n                &lt;div class="col-md-5">\r\n                    &lt;div class="card-text">\r\n                        &lt;h2>10%  &lt;span class="orng-span">Interest Rate&lt;/span>&lt;/h2>\r\n                        &lt;p>We are offering up to 10% Interest rate to our clients.\r\n                            This promotion is available to New &amp; Existing Clients.\r\n                            Offer validity from July 01, 2020.&lt;/p>\r\n                        &lt;p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.&lt;/p>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n            &lt;div class="row promotions-mobile">\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-img">\r\n                        &lt;h2>10%  &lt;span class="orng-span">Interest Rate&lt;/span>&lt;/h2>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n                &lt;div class="col-md-6">\r\n                    &lt;div class="card-text">\r\n                        &lt;p>We are offering up to 10% Interest rate to our clients.\r\n                            This promotion is available to New &amp; Existing Clients.\r\n                            Offer validity from July 01, 2020.&lt;/p>\r\n                        &lt;p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.&lt;/p>\r\n                        &lt;a href="&lt;?php the_permalink()?>" class="general-button-2">Get more info&lt;/a>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n        &lt;/div>\r\n            &lt;div class="interest-rate-line">\r\n                &lt;div class="container">\r\n                    &lt;div class="row">\r\n                        &lt;div class="col-md-3">\r\n                            &lt;div class="horz-line">\r\n                                &lt;div class="diamond">&lt;/div>\r\n                            &lt;/div>\r\n                            &lt;div class="interest-rate-col">\r\n                                &lt;p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.&lt;/p>\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="col-md-3">\r\n                            &lt;div class="horz-line">\r\n                                &lt;div class="diamond">&lt;/div>\r\n                            &lt;/div>\r\n                            &lt;div class="interest-rate-col">\r\n                                &lt;p>After the deposit the client should get his interest rate on a daily basis.&lt;/p>\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="col-md-3">\r\n                            &lt;div class="horz-line">\r\n                                &lt;div class="diamond">&lt;/div>\r\n                            &lt;/div>\r\n                            &lt;div class="interest-rate-col">\r\n                                &lt;p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.&lt;/p>\r\n                            &lt;/div>\r\n                        &lt;/div>\r\n                        &lt;div class="col-md-3">\r\n                            &lt;div class="horz-line">\r\n                                &lt;div class="diamond">&lt;/div>\r\n                            &lt;/div>\r\n                            &lt;div class="interest-rate-col">\r\n                                &lt;p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.&lt;/p>\r\n                            &lt;/div>\r\n                            &lt;button type="button" class="btn btn-defualt register-now">Register Now&lt;span class="glyphicon glyphicon-menu-right">&lt;/span>&lt;/button>&lt;/button>\r\n                        &lt;/div>\r\n                    &lt;/div>\r\n                &lt;/div>\r\n            &lt;/div>\r\n    &lt;/section>\r\n&lt;/div>\r</code></pre>\n<!-- /wp:code -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:33:09', '2021-07-31 06:33:09', '', 52, 'http://localhost:8000/?p=74', 0, 'revision', '', 0),
(75, 1, '2021-07-31 06:34:54', '2021-07-31 06:34:54', '<!-- wp:image {"id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:html -->\n<div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</span></h2>\n                        \n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n<!-- /wp:html -->\n\n<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:34:54', '2021-07-31 06:34:54', '', 52, 'http://localhost:8000/?p=75', 0, 'revision', '', 0),
(76, 1, '2021-07-31 06:35:10', '2021-07-31 06:35:10', '<!-- wp:html -->\n<div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</span></h2>\n                        \n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:35:10', '2021-07-31 06:35:10', '', 52, 'http://localhost:8000/?p=76', 0, 'revision', '', 0),
(78, 1, '2021-07-31 06:38:04', '2021-07-31 06:38:04', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="<?php the_permalink()?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:38:04', '2021-07-31 06:38:04', '', 52, 'http://localhost:8000/?p=78', 0, 'revision', '', 0),
(79, 1, '2021-07-31 06:38:52', '2021-07-31 06:38:52', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:38:52', '2021-07-31 06:38:52', '', 52, 'http://localhost:8000/?p=79', 0, 'revision', '', 0),
(80, 1, '2021-07-31 06:48:20', '2021-07-31 06:48:20', '<!-- wp:paragraph -->\n<p>&lt;p&gt;Sharing&nbsp;is&nbsp;Caring.&nbsp;Bring&nbsp;your&nbsp;friends&nbsp;to&nbsp;EverFX&nbsp;and&nbsp;get&nbsp;rewarded.&nbsp;Share&nbsp;your&nbsp;trading&nbsp;experience&nbsp;with&nbsp;friends&nbsp;you&nbsp;care&nbsp;about.&nbsp;&lt;span&nbsp;class="orng-span"&gt;Claim&nbsp;your&nbsp;BONUS&lt;/span&gt;.&nbsp;This&nbsp;Promotion&nbsp;is&nbsp;available&nbsp;to&nbsp;all&nbsp;Existing&nbsp;Clients&nbsp;provided&nbsp;that&nbsp;they&nbsp;have&nbsp;already&nbsp;completed&nbsp;the&nbsp;steps&nbsp;required&nbsp;for&nbsp;the&nbsp;account&nbsp;opening&nbsp;process,&nbsp;the&nbsp;Client’s&nbsp;due&nbsp;diligence&nbsp;and&nbsp;‘Know&nbsp;Your&nbsp;Client’&nbsp;procedures&nbsp;and&nbsp;therefore&nbsp;their&nbsp;account&nbsp;is&nbsp;activated.&lt;/p&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;p&gt;The&nbsp;Client&nbsp;also&nbsp;acknowledges&nbsp;that&nbsp;any&nbsp;information&nbsp;provided&nbsp;to&nbsp;the&nbsp;Company&nbsp;shall&nbsp;be&nbsp;true&nbsp;and&nbsp;accurate,&nbsp;act&nbsp;in&nbsp;good&nbsp;faith&nbsp;and&nbsp;in&nbsp;accordance&nbsp;with&nbsp;the&nbsp;&lt;span&nbsp;class="orng-span"&gt;&nbsp;terms&nbsp;of&nbsp;the&nbsp;Promotion&nbsp;&lt;/span&gt;.&lt;/p&gt;</p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:48:20', '2021-07-31 06:48:20', '', 52, 'http://localhost:8000/?p=80', 0, 'revision', '', 0),
(82, 1, '2021-07-31 06:55:11', '2021-07-31 06:55:11', '<!-- wp:html -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 06:55:11', '2021-07-31 06:55:11', '', 52, 'http://localhost:8000/?p=82', 0, 'revision', '', 0),
(83, 1, '2021-07-31 07:00:07', '2021-07-31 07:00:07', '<!-- wp:html -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n<!-- /wp:html -->\n\n<!-- wp:html -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:00:07', '2021-07-31 07:00:07', '', 52, 'http://localhost:8000/?p=83', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(84, 1, '2021-07-31 07:00:56', '2021-07-31 07:00:56', '<!-- wp:html -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n<!-- /wp:html -->\n\n<!-- wp:html -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:00:56', '2021-07-31 07:00:56', '', 52, 'http://localhost:8000/?p=84', 0, 'revision', '', 0),
(85, 1, '2021-07-31 07:04:29', '2021-07-31 07:04:29', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n\n<!-- /wp:html -->', '', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:04:29', '2021-07-31 07:04:29', '', 52, 'http://localhost:8000/?p=85', 0, 'revision', '', 0),
(86, 1, '2021-07-31 07:13:10', '2021-07-31 07:13:10', '<!-- wp:image {"align":"center","id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. Claim your BONUS. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the terms of the Promotion.</p>\n<!-- /wp:paragraph -->', 'Refer a friend', '', 'publish', 'closed', 'open', '', 'refer-a-friend', '', '', '2021-08-01 06:36:28', '2021-08-01 06:36:28', '', 0, 'http://localhost:8000/?p=86', 0, 'post', '', 0),
(87, 1, '2021-07-31 07:13:10', '2021-07-31 07:13:10', '<!-- wp:paragraph -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:Make a deposit into your trading account Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 07:13:10', '2021-07-31 07:13:10', '', 86, 'http://localhost:8000/?p=87', 0, 'revision', '', 0),
(89, 1, '2021-07-31 07:27:01', '2021-07-31 07:27:01', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n<!-- /wp:html -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:27:01', '2021-07-31 07:27:01', '', 52, 'http://localhost:8000/?p=89', 0, 'revision', '', 0),
(90, 1, '2021-07-31 07:27:50', '2021-07-31 07:27:50', '<!-- wp:paragraph -->\n<p><a href="http://localhost:8000/promotions/" data-type="page" data-id="52">Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:Make a deposit into your trading account.Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</a></p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 07:27:50', '2021-07-31 07:27:50', '', 86, 'http://localhost:8000/?p=90', 0, 'revision', '', 0),
(91, 1, '2021-07-31 07:29:46', '2021-07-31 07:29:46', '<!-- wp:paragraph -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:Make a deposit into your trading account.Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 07:29:46', '2021-07-31 07:29:46', '', 86, 'http://localhost:8000/?p=91', 0, 'revision', '', 0),
(92, 1, '2021-07-31 07:31:28', '2021-07-31 07:31:28', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n<!-- /wp:html -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-autosave-v1', '', '', '2021-07-31 07:31:28', '2021-07-31 07:31:28', '', 52, 'http://localhost:8000/?p=92', 0, 'revision', '', 0),
(93, 1, '2021-07-31 07:31:52', '2021-07-31 07:31:52', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="promotions/up-to-100-rebate-bonus/(opens in a new tab)" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n<!-- /wp:html -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:31:52', '2021-07-31 07:31:52', '', 52, 'http://localhost:8000/?p=93', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(94, 1, '2021-07-31 07:36:29', '2021-07-31 07:36:29', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="get_post(86)" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n<!-- /wp:html -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 07:36:29', '2021-07-31 07:36:29', '', 52, 'http://localhost:8000/?p=94', 0, 'revision', '', 0),
(95, 1, '2021-07-31 08:25:28', '2021-07-31 08:25:28', '<!-- wp:html -->\n<div class="promotions-container">\n    <section class="refer-friend">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                        <a href="<?php get_permalink(86); ?>" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <h2><span class="orng-span">Refer</span> a friend</h2>\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2><span class="orng-span">Invite a friend</span>\n                        <span class="subtext">And get <span class="orng-span"> 50</span> tokens</h3>\n                        </h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. <span class="orng-span">Claim your BONUS</span>. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n                    <p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the <span class="orng-span"> terms of the Promotion </span>.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="rebate-bonus">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-5">\n                    <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>Up to 100% <span class="orng-span">Rebate Bonus</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company.\n                    Only few steps to get started:</p>\n                    <p>Make a deposit into your trading account\n                    Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.\n                    The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n                    <a href="#" class="general-button-2">Get more info</a>\n                </div>\n            </div>\n        </div>\n    </section>\n    <section class="interest-rate">\n        <div class="container">\n            <div class="row promotions-desktop">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n                <div class="col-md-5">\n                    <div class="card-text">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                    </div>\n                </div>\n            </div>\n            <div class="row promotions-mobile">\n                <div class="col-md-6">\n                    <div class="card-img">\n                        <h2>10%  <span class="orng-span">Interest Rate</span></h2>\n                    </div>\n                </div>\n                <div class="col-md-6">\n                    <div class="card-text">\n                        <p>We are offering up to 10% Interest rate to our clients.\n                            This promotion is available to New & Existing Clients.\n                            Offer validity from July 01, 2020.</p>\n                        <p>The client needs to read carefully the present Terms and Conditions and to explicitly agree with them.</p>\n                        <a href="#" class="general-button-2">Get more info</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n            <div class="interest-rate-line">\n                <div class="container">\n                    <div class="row">\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The client should proceed to a deposit into his/her trading account which he/she maintains with the Company within the Promotional period as per Clause 12.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>After the deposit the client should get his interest rate on a daily basis.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>Interest is paid only at the first Deposited Amount done by the client within the Promotional Period. Any following deposit(s) will not be calculated for Interest’s purposes and not be subject to this Offer.</p>\n                            </div>\n                        </div>\n                        <div class="col-md-3">\n                            <div class="horz-line">\n                                <div class="diamond"></div>\n                            </div>\n                            <div class="interest-rate-col">\n                                <p>The Company will assess the client’s eligibility to the Offer and only then to provide the 10% Interest on the first deposited amount within the Promotional Period. The interest rate is available up to a maximum Deposit amount of USD 50,000 or 50,000 of any other currency amount.</p>\n                            </div>\n                            <button type="button" class="btn btn-defualt register-now">Register Now<span class="glyphicon glyphicon-menu-right"></span></button></button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n    </section>\n</div>\n<!-- /wp:html -->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 08:25:28', '2021-07-31 08:25:28', '', 52, 'http://localhost:8000/?p=95', 0, 'revision', '', 0),
(96, 1, '2021-07-31 08:30:36', '2021-07-31 08:30:36', '<!-- wp:html /-->', 'Promotions', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2021-07-31 08:30:36', '2021-07-31 08:30:36', '', 52, 'http://localhost:8000/?p=96', 0, 'revision', '', 0),
(98, 1, '2021-07-31 09:07:34', '2021-07-31 09:07:34', '<!-- wp:paragraph -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Make a deposit into your trading account Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager. The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 09:07:34', '2021-07-31 09:07:34', '', 86, 'http://localhost:8000/?p=98', 0, 'revision', '', 0),
(99, 1, '2021-07-31 10:18:24', '2021-07-31 10:18:24', '<!-- wp:image {"align":"center","id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:Make a deposit into your trading account.Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager.The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 10:18:24', '2021-07-31 10:18:24', '', 86, 'http://localhost:8000/?p=99', 0, 'revision', '', 0),
(100, 1, '2021-07-31 10:19:00', '2021-07-31 10:19:00', '<!-- wp:image {"align":"center","id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Good&nbsp;news!&nbsp;All&nbsp;new&nbsp;and&nbsp;existing&nbsp;clients&nbsp;can&nbsp;benefit&nbsp;the&nbsp;BONUS.&nbsp;This&nbsp;Promotion&nbsp;is&nbsp;offered&nbsp;on&nbsp;per&nbsp;client&nbsp;basis&nbsp;regardless&nbsp;of&nbsp;the&nbsp;number&nbsp;of&nbsp;accounts&nbsp;the&nbsp;client&nbsp;maintains&nbsp;with&nbsp;the&nbsp;Company.&nbsp;Only&nbsp;few&nbsp;steps&nbsp;to&nbsp;get&nbsp;started:Make&nbsp;a&nbsp;deposit&nbsp;into&nbsp;your&nbsp;trading&nbsp;account.Within&nbsp;5&nbsp;business&nbsp;days&nbsp;you&nbsp;should&nbsp;get&nbsp;your&nbsp;Bonus&nbsp;for&nbsp;which&nbsp;you&nbsp;need&nbsp;to&nbsp;provide&nbsp;your&nbsp;approval&nbsp;to&nbsp;your&nbsp;Account&nbsp;Manager.The&nbsp;rebate&nbsp;bonus&nbsp;will&nbsp;be&nbsp;amounted&nbsp;up&nbsp;to&nbsp;the&nbsp;100%&nbsp;of&nbsp;the&nbsp;client’s&nbsp;deposits.&nbsp;The&nbsp;maximum&nbsp;rebate&nbsp;bonus&nbsp;to&nbsp;be&nbsp;offered&nbsp;by&nbsp;the&nbsp;Company&nbsp;per&nbsp;client&nbsp;is&nbsp;set&nbsp;at&nbsp;USD&nbsp;10,000&nbsp;or&nbsp;equivalent&nbsp;currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 10:19:00', '2021-07-31 10:19:00', '', 86, 'http://localhost:8000/?p=100', 0, 'revision', '', 0),
(102, 1, '2021-07-31 10:21:18', '2021-07-31 10:21:18', '<!-- wp:image {"align":"center","id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Good news! All new and existing clients can benefit the BONUS. This Promotion is offered on per client basis regardless of the number of accounts the client maintains with the Company. Only few steps to get started:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Make a deposit into your trading account Within 5 business days you should get your Bonus for which you need to provide your approval to your Account Manager. The rebate bonus will be amounted up to the 100% of the client’s deposits. The maximum rebate bonus to be offered by the Company per client is set at USD 10,000 or equivalent currency.</p>\n<!-- /wp:paragraph -->', 'Up to 100% Rebate Bonus', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-07-31 10:21:18', '2021-07-31 10:21:18', '', 86, 'http://localhost:8000/?p=102', 0, 'revision', '', 0),
(104, 1, '2021-08-01 02:58:48', '2021-08-01 02:58:48', '<!-- wp:image {"align":"center","id":69,"width":681,"height":406,"sizeSlug":"large","linkDestination":"none"} -->\n<div class="wp-block-image"><figure class="aligncenter size-large is-resized"><img src="http://localhost:8000/wp-content/uploads/2021/07/Group-4.png" alt="" class="wp-image-69" width="681" height="406"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sharing is Caring. Bring your friends to EverFX and get rewarded. Share your trading experience with friends you care about. Claim your BONUS. This Promotion is available to all Existing Clients provided that they have already completed the steps required for the account opening process, the Client’s due diligence and ‘Know Your Client’ procedures and therefore their account is activated.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>The Client also acknowledges that any information provided to the Company shall be true and accurate, act in good faith and in accordance with the terms of the Promotion.</p>\n<!-- /wp:paragraph -->', 'Refer a friend', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2021-08-01 02:58:48', '2021-08-01 02:58:48', '', 86, 'http://localhost:8000/?p=104', 0, 'revision', '', 0),
(105, 1, '2021-08-02 09:29:10', '2021-08-02 09:29:10', '', 'Account Types', '', 'inherit', 'closed', 'closed', '', '58-autosave-v1', '', '', '2021-08-02 09:29:10', '2021-08-02 09:29:10', '', 58, 'http://localhost:8000/?p=105', 0, 'revision', '', 0),
(106, 1, '2021-08-07 13:31:43', '2021-08-07 13:31:43', '', 'Company', '', 'inherit', 'closed', 'closed', '', '7-autosave-v1', '', '', '2021-08-07 13:31:43', '2021-08-07 13:31:43', '', 7, 'http://localhost:8000/?p=106', 0, 'revision', '', 0),
(109, 1, '2021-08-07 17:07:22', '2021-08-07 17:07:22', '<!-- wp:html -->\n<div class="custom-header-bg">\n    <div class="container">\n        <div class="row">\n            <div class="col-md-12">\n                <div class="header-container">\n                    <div class="header-banner">\n                        <h2 class="primary-header">Three <span class="orng-span">Account Types</span>. Same Great Service!</h2>\n                        <p class="subheading">Investing has never been easier. Everything you are looking for in an ultimate investment platform — on the device of your choice.</p>\n                        <a href="#" class="stocks-button">Forex</a>\n                        <a href="#" class="stocks-button">Stocks</a>\n                        <a href="#" class="stocks-button">Indices</a>\n                        <a href="#" class="stocks-button">Commodities</a>\n                        <a href="#" class="stocks-button">Crypto</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n<!-- /wp:html -->', 'Markets', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2021-08-07 17:07:22', '2021-08-07 17:07:22', '', 9, 'http://localhost:8000/?p=109', 0, 'revision', '', 0),
(111, 1, '2021-08-07 17:09:53', '2021-08-07 17:09:53', '<!-- wp:html /-->', 'Markets', '', 'inherit', 'closed', 'closed', '', '9-autosave-v1', '', '', '2021-08-07 17:09:53', '2021-08-07 17:09:53', '', 9, 'http://localhost:8000/?p=111', 0, 'revision', '', 0),
(112, 1, '2021-08-22 21:57:48', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-08-22 21:57:48', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=112', 0, 'post', '', 0),
(113, 1, '2021-08-22 22:20:50', '2021-08-22 22:20:50', '<!-- wp:paragraph -->\n<p>Netherlands, The Consumer Spending Volume: -13.5% (January) vs previous -11.9%</p>\n<!-- /wp:paragraph -->', 'News', '', 'publish', 'closed', 'open', '', 'news', '', '', '2021-08-22 23:08:02', '2021-08-22 23:08:02', '', 0, 'http://localhost:8000/?p=113', 0, 'post', '', 0),
(114, 1, '2021-08-22 22:20:50', '2021-08-22 22:20:50', '<!-- wp:paragraph -->\n<p>Netherlands, The Consumer Spending Volume: -13.5% (January) vs previous -11.9%</p>\n<!-- /wp:paragraph -->', 'News', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2021-08-22 22:20:50', '2021-08-22 22:20:50', '', 113, 'http://localhost:8000/?p=114', 0, 'revision', '', 0),
(116, 1, '2021-09-13 22:03:51', '2021-09-13 22:03:51', '', 'client', '', 'publish', 'closed', 'closed', '', 'client', '', '', '2021-09-13 22:03:51', '2021-09-13 22:03:51', '', 0, 'http://localhost:8000/?page_id=116', 0, 'page', '', 0),
(118, 1, '2021-09-13 22:03:51', '2021-09-13 22:03:51', '', 'client', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2021-09-13 22:03:51', '2021-09-13 22:03:51', '', 116, 'http://localhost:8000/?p=118', 0, 'revision', '', 0),
(119, 1, '2021-09-13 22:04:08', '2021-09-13 22:04:08', '', 'portal', '', 'publish', 'closed', 'closed', '', 'portal', '', '', '2021-09-13 22:13:12', '2021-09-13 22:13:12', '', 116, 'http://localhost:8000/?page_id=119', 0, 'page', '', 0),
(121, 1, '2021-09-13 22:04:08', '2021-09-13 22:04:08', '', 'portal', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2021-09-13 22:04:08', '2021-09-13 22:04:08', '', 119, 'http://localhost:8000/?p=121', 0, 'revision', '', 0),
(122, 1, '2021-09-22 08:44:08', '2021-09-22 08:44:08', '', 'FX', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2021-09-22 08:44:08', '2021-09-22 08:44:08', '', 32, 'http://localhost:8000/?p=122', 0, 'revision', '', 0),
(123, 1, '2021-09-22 08:44:27', '2021-09-22 08:44:27', '', 'Stocks', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2021-09-22 08:44:27', '2021-09-22 08:44:27', '', 34, 'http://localhost:8000/?p=123', 0, 'revision', '', 0),
(124, 1, '2021-09-22 08:44:49', '2021-09-22 08:44:49', '', 'Indices', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2021-09-22 08:44:49', '2021-09-22 08:44:49', '', 36, 'http://localhost:8000/?p=124', 0, 'revision', '', 0),
(125, 1, '2021-09-22 08:45:38', '2021-09-22 08:45:38', '', 'Commodities', '', 'publish', 'closed', 'closed', '', 'commodities', '', '', '2021-09-22 08:45:38', '2021-09-22 08:45:38', '', 9, 'http://localhost:8000/?page_id=125', 0, 'page', '', 0),
(126, 1, '2021-09-22 08:45:38', '2021-09-22 08:45:38', '', 'Commodities', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2021-09-22 08:45:38', '2021-09-22 08:45:38', '', 125, 'http://localhost:8000/?p=126', 0, 'revision', '', 0),
(127, 1, '2021-09-22 08:46:16', '2021-09-22 08:46:16', '', 'Crypto', '', 'publish', 'closed', 'closed', '', 'crypto', '', '', '2021-09-22 08:46:16', '2021-09-22 08:46:16', '', 9, 'http://localhost:8000/?page_id=127', 0, 'page', '', 0),
(128, 1, '2021-09-22 08:46:16', '2021-09-22 08:46:16', '', 'Crypto', '', 'inherit', 'closed', 'closed', '', '127-revision-v1', '', '', '2021-09-22 08:46:16', '2021-09-22 08:46:16', '', 127, 'http://localhost:8000/?p=128', 0, 'revision', '', 0),
(129, 1, '2021-10-16 03:51:04', '2021-09-22 08:49:18', '324 trading pairs', '', '', 'publish', 'closed', 'closed', '', '129', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 9, 'http://localhost:8000/?p=129', 10, 'nav_menu_item', '', 0),
(130, 1, '2021-10-16 03:51:04', '2021-09-22 08:49:18', '324 trading pairs', '', '', 'publish', 'closed', 'closed', '', '130', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 9, 'http://localhost:8000/?p=130', 9, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(131, 1, '2021-09-22 08:49:04', '2021-09-22 08:49:04', '', 'Arena', '', 'publish', 'closed', 'closed', '', 'arena', '', '', '2021-09-22 08:49:04', '2021-09-22 08:49:04', '', 34, 'http://localhost:8000/?page_id=131', 0, 'page', '', 0),
(132, 1, '2021-09-22 08:49:04', '2021-09-22 08:49:04', '', 'Arena', '', 'inherit', 'closed', 'closed', '', '131-revision-v1', '', '', '2021-09-22 08:49:04', '2021-09-22 08:49:04', '', 131, 'http://localhost:8000/?p=132', 0, 'revision', '', 0),
(133, 1, '2021-10-16 03:51:04', '2021-09-22 08:49:56', ' ', '', '', 'publish', 'closed', 'closed', '', '133', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 34, 'http://localhost:8000/?p=133', 7, 'nav_menu_item', '', 0),
(134, 1, '2021-09-22 09:04:53', '2021-09-22 09:04:53', '', 'EURUSD', '', 'publish', 'closed', 'closed', '', 'eurusd', '', '', '2021-09-22 09:04:53', '2021-09-22 09:04:53', '', 32, 'http://localhost:8000/?page_id=134', 0, 'page', '', 0),
(135, 1, '2021-09-22 09:04:53', '2021-09-22 09:04:53', '', 'EURUSD', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2021-09-22 09:04:53', '2021-09-22 09:04:53', '', 134, 'http://localhost:8000/?p=135', 0, 'revision', '', 0),
(136, 1, '2021-10-16 03:51:04', '2021-09-22 09:05:54', 'currency', '', '', 'publish', 'closed', 'closed', '', '136', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 32, 'http://localhost:8000/?p=136', 4, 'nav_menu_item', '', 0),
(137, 1, '2021-10-16 03:51:04', '2021-09-22 11:57:38', ' ', '', '', 'publish', 'closed', 'closed', '', '137', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=137', 6, 'nav_menu_item', '', 0),
(138, 1, '2021-09-24 03:15:19', '2021-09-24 03:15:19', '', 'Default Registration', '', 'publish', 'closed', 'closed', '', 'default-registration', '', '', '2021-09-24 03:15:19', '2021-09-24 03:15:19', '', 0, 'http://localhost:8000/um_form/default-registration/', 0, 'um_form', '', 0),
(139, 1, '2021-09-24 03:15:19', '2021-09-24 03:15:19', '', 'Default Login', '', 'publish', 'closed', 'closed', '', 'default-login', '', '', '2021-09-24 03:15:19', '2021-09-24 03:15:19', '', 0, 'http://localhost:8000/um_form/default-login/', 0, 'um_form', '', 0),
(140, 1, '2021-09-24 03:15:20', '2021-09-24 03:15:20', '', 'Default Profile', '', 'publish', 'closed', 'closed', '', 'default-profile', '', '', '2021-09-24 03:15:20', '2021-09-24 03:15:20', '', 0, 'http://localhost:8000/um_form/default-profile/', 0, 'um_form', '', 0),
(141, 1, '2021-09-24 03:15:20', '2021-09-24 03:15:20', '', 'Members', '', 'publish', 'closed', 'closed', '', 'members', '', '', '2021-09-24 03:15:20', '2021-09-24 03:15:20', '', 0, 'http://localhost:8000/um_directory/members/', 0, 'um_directory', '', 0),
(142, 1, '2021-09-24 09:10:46', '2021-09-24 09:10:46', '', 'Stocks', '', 'inherit', 'closed', 'closed', '', '34-autosave-v1', '', '', '2021-09-24 09:10:46', '2021-09-24 09:10:46', '', 34, 'http://localhost:8000/?p=142', 0, 'revision', '', 0),
(143, 1, '2021-10-16 03:47:31', '2021-10-16 03:47:31', '', 'Stocks', '', 'publish', 'open', 'open', '', 'stocks', '', '', '2021-10-16 03:47:32', '2021-10-16 03:47:32', '', 0, 'http://localhost:8000/?p=143', 0, 'post', '', 0),
(144, 1, '2021-10-16 03:47:31', '2021-10-16 03:47:31', '', 'Stocks', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2021-10-16 03:47:31', '2021-10-16 03:47:31', '', 143, 'http://localhost:8000/?p=144', 0, 'revision', '', 0),
(145, 1, '2021-10-16 03:48:02', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-10-16 03:48:02', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=145', 1, 'nav_menu_item', '', 0),
(146, 1, '2021-10-16 03:51:04', '2021-10-16 03:50:36', '324 trading pairs', '', '', 'publish', 'closed', 'closed', '', '146', '', '', '2021-10-16 03:51:04', '2021-10-16 03:51:04', '', 0, 'http://localhost:8000/?p=146', 5, 'nav_menu_item', '', 0),
(147, 1, '2021-10-16 05:15:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-10-16 05:15:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=147', 0, 'post', '', 0),
(148, 1, '2021-10-16 05:17:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-10-16 05:17:31', '0000-00-00 00:00:00', '', 0, 'http://localhost:8000/?p=148', 0, 'post', '', 0),
(149, 1, '2021-11-05 21:51:52', '2021-11-05 21:51:52', '[ultimatemember form_id="140"]', 'User', '', 'publish', 'closed', 'closed', '', 'user', '', '', '2021-11-05 21:51:52', '2021-11-05 21:51:52', '', 0, 'http://localhost:8000/user/', 0, 'page', '', 0),
(150, 1, '2021-11-05 21:51:52', '2021-11-05 21:51:52', ' ', '', '', 'publish', 'closed', 'closed', '', '150', '', '', '2021-11-05 21:51:52', '2021-11-05 21:51:52', '', 0, 'http://localhost:8000/uncategorized/150/', 17, 'nav_menu_item', '', 0),
(151, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '[ultimatemember form_id="139"]', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/login/', 0, 'page', '', 0),
(152, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '152', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/152/', 18, 'nav_menu_item', '', 0),
(153, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '[ultimatemember form_id="138"]', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/register/', 0, 'page', '', 0),
(154, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '154', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/154/', 19, 'nav_menu_item', '', 0),
(155, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '[ultimatemember form_id="141"]', 'Members', '', 'publish', 'closed', 'closed', '', 'members', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/members/', 0, 'page', '', 0),
(156, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '156', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/156/', 20, 'nav_menu_item', '', 0),
(157, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 'Logout', '', 'publish', 'closed', 'closed', '', 'logout', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/logout/', 0, 'page', '', 0),
(158, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '158', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/158/', 21, 'nav_menu_item', '', 0),
(159, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '[ultimatemember_account]', 'Account', '', 'publish', 'closed', 'closed', '', 'account', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/account/', 0, 'page', '', 0),
(160, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '160', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/160/', 22, 'nav_menu_item', '', 0),
(161, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', '[ultimatemember_password]', 'Password Reset', '', 'publish', 'closed', 'closed', '', 'password-reset', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/password-reset/', 0, 'page', '', 0),
(162, 1, '2021-11-05 21:51:53', '2021-11-05 21:51:53', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2021-11-05 21:51:53', '2021-11-05 21:51:53', '', 0, 'http://localhost:8000/uncategorized/162/', 23, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 2, 0),
(13, 2, 0),
(14, 2, 0),
(26, 2, 0),
(27, 2, 0),
(31, 4, 0),
(38, 2, 0),
(40, 2, 0),
(53, 2, 0),
(56, 2, 0),
(59, 2, 0),
(86, 5, 0),
(113, 7, 0),
(129, 2, 0),
(130, 2, 0),
(133, 2, 0),
(136, 2, 0),
(137, 2, 0),
(143, 8, 0),
(146, 2, 0),
(150, 2, 0),
(152, 2, 0),
(154, 2, 0),
(156, 2, 0),
(158, 2, 0),
(160, 2, 0),
(162, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 23),
(4, 4, 'nav_menu', '', 0, 1),
(5, 5, 'category', '', 0, 1),
(6, 6, 'category', '', 0, 0),
(7, 7, 'category', '', 0, 1),
(8, 8, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Navigation Bar', 'navigation-bar', 0),
(4, 'Footer Menu', 'footer-menu', 0),
(5, 'Promotions', 'promotions', 0),
(6, 'Education', 'education', 0),
(7, 'FXStreet', 'fxstreet', 0),
(8, 'Markets', 'markets', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_um_metadata`
#

DROP TABLE IF EXISTS `wp_um_metadata`;


#
# Table structure of table `wp_um_metadata`
#

CREATE TABLE `wp_um_metadata` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `um_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `um_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id_indx` (`user_id`),
  KEY `meta_key_indx` (`um_key`),
  KEY `meta_value_indx` (`um_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_um_metadata`
#

#
# End of data contents of table `wp_um_metadata`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'root'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"680ba38dc0df3a31e118d7428f9c50928b846e6caca24890944912c1916b06bc";a:4:{s:10:"expiration";i:1636321272;s:2:"ip";s:10:"172.19.0.1";s:2:"ua";s:131:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36 Edg/95.0.1020.40";s:5:"login";i:1636148472;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:10:"172.19.0.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:11:"link-target";i:1;s:15:"title-attribute";i:2;s:3:"xfn";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(21, 1, 'nav_menu_recently_edited', '2'),
(22, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(23, 1, 'wp_user-settings-time', '1636148477'),
(24, 1, 'account_status', 'approved'),
(25, 1, 'um_member_directory_data', 'a:5:{s:14:"account_status";s:8:"approved";s:15:"hide_in_members";b:0;s:13:"profile_photo";b:0;s:11:"cover_photo";b:0;s:8:"verified";b:0;}'),
(26, 1, '_um_last_login', '1636148472'),
(27, 1, 'wpmdb_licence_key', '5832aa4b-a8b2-4ac8-882c-a176cd414436') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'root', '$P$BjxVGMnz.SOY2/a0/bPRAGhS7x0ptc1', 'root', 'asem.abdou@flexistax.com', 'http://localhost:8000', '2021-07-07 13:59:24', '', 0, 'root') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

